"use client";

import { create } from "zustand";
import type { AppUser } from "@/types";

interface AuthState {
  user:       AppUser | null;
  firebaseUser: import("firebase/auth").User | null;
  loading:    boolean;
  setUser:    (user: AppUser | null) => void;
  setFirebaseUser: (u: import("firebase/auth").User | null) => void;
  setLoading: (loading: boolean) => void;
  isAdmin:    () => boolean;
  isWriter:   () => boolean;
  canWrite:   () => boolean;
  reset:      () => void;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user:         null,
  firebaseUser: null,
  loading:      true,

  setUser:         (user) => set({ user }),
  setFirebaseUser: (firebaseUser) => set({ firebaseUser }),
  setLoading:      (loading) => set({ loading }),

  isAdmin:  () => get().user?.role === "admin",
  isWriter: () => get().user?.role === "writer",
  canWrite: () => {
    const role = get().user?.role;
    return role === "admin" || role === "writer";
  },

  reset: () => set({ user: null, firebaseUser: null, loading: false }),
}));
