"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { autoSaveDraft } from "@/lib/firebase/articles";
import { countWords } from "@/lib/utils";

export type SaveStatus = "idle" | "saving" | "saved" | "error";

interface AutoSaveOptions {
  draftId:    string | null;
  title:      string;
  contentJSON: Record<string, unknown>;
  contentHTML: string;
  enabled:    boolean;
  delayMs?:   number;
}

export function useAutoSave({
  draftId,
  title,
  contentJSON,
  contentHTML,
  enabled,
  delayMs = 3000,
}: AutoSaveOptions) {
  const [status,    setStatus]    = useState<SaveStatus>("idle");
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const timerRef                  = useRef<ReturnType<typeof setTimeout> | null>(null);
  const mountedRef                = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    return () => { mountedRef.current = false; };
  }, []);

  // Save to localStorage immediately as backup
  const saveLocal = useCallback(
    (id: string) => {
      try {
        localStorage.setItem(
          `draft_${id}`,
          JSON.stringify({ title, contentJSON, savedAt: new Date().toISOString() })
        );
      } catch {
        // ignore storage quota errors
      }
    },
    [title, contentJSON]
  );

  // Save to Firestore
  const saveRemote = useCallback(async () => {
    if (!draftId || !enabled) return;

    setStatus("saving");
    saveLocal(draftId);

    try {
      await autoSaveDraft(draftId, {
        title,
        contentJSON,
        wordCount: countWords(contentHTML),
      });

      if (!mountedRef.current) return;
      setStatus("saved");
      setLastSaved(new Date());

      // Reset to idle after 3s
      setTimeout(() => {
        if (mountedRef.current) setStatus("idle");
      }, 3000);
    } catch {
      if (!mountedRef.current) return;
      setStatus("error");
    }
  }, [draftId, title, contentJSON, contentHTML, enabled, saveLocal]);

  // Debounced save trigger
  useEffect(() => {
    if (!enabled || !draftId) return;

    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(saveRemote, delayMs);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [title, contentJSON, enabled, draftId, delayMs, saveRemote]);

  // Restore from localStorage if Firestore fails
  const restoreLocal = useCallback((id: string) => {
    try {
      const raw = localStorage.getItem(`draft_${id}`);
      if (!raw) return null;
      return JSON.parse(raw) as {
        title: string;
        contentJSON: Record<string, unknown>;
        savedAt: string;
      };
    } catch {
      return null;
    }
  }, []);

  const clearLocal = useCallback((id: string) => {
    localStorage.removeItem(`draft_${id}`);
  }, []);

  return { status, lastSaved, restoreLocal, clearLocal };
}
