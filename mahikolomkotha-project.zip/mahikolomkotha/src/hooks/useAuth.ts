"use client";

import { useEffect } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "@/lib/firebase/config";
import { getUserDoc } from "@/lib/firebase/auth";
import { useAuthStore } from "@/stores/authStore";

// Call this ONCE at the root layout level
export function useAuthProvider() {
  const { setUser, setFirebaseUser, setLoading } = useAuthStore();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setFirebaseUser(firebaseUser);
      if (firebaseUser) {
        const appUser = await getUserDoc(firebaseUser.uid);
        setUser(appUser);
      } else {
        setUser(null);
      }
      setLoading(false);
    });
    return unsubscribe;
  }, [setUser, setFirebaseUser, setLoading]);
}

// Use anywhere to access auth state
export function useAuth() {
  const { user, firebaseUser, loading, isAdmin, isWriter, canWrite } =
    useAuthStore();
  return { user, firebaseUser, loading, isAdmin: isAdmin(), isWriter: isWriter(), canWrite: canWrite() };
}
