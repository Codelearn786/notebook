"use client";
import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { getPublications, createPublication, deletePublication } from "@/lib/firebase/firestore";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Archive, Plus, Trash2, Newspaper } from "lucide-react";
import { formatDate } from "@/lib/utils";
import type { Publication } from "@/types";

export default function ArchivePage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [pubs, setPubs] = useState<Publication[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ title: "", newspaperName: "", publicationDate: "", category: "article" });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!user) return;
    getPublications(user.uid).then((d) => { setPubs(d); setLoading(false); });
  }, [user]);

  const handleAdd = async () => {
    if (!form.title || !form.newspaperName || !user) return;
    setSaving(true);
    try {
      const id = await createPublication({ ...form, authorId: user.uid, tags: [], pdfUrl: undefined });
      const newPub: Publication = { id, ...form, authorId: user.uid, tags: [], createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
      setPubs([newPub, ...pubs]);
      setOpen(false);
      setForm({ title: "", newspaperName: "", publicationDate: "", category: "article" });
      toast({ title: "Publication added" });
    } finally { setSaving(false); }
  };

  return (
    <div className="container mx-auto max-w-3xl px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Archive className="h-6 w-6 text-primary" />
          <div><h1 className="text-2xl font-bold bengali-heading">Publication Archive</h1>
          <p className="text-sm text-muted-foreground">Newspaper & magazine records</p></div>
        </div>
        <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-4 w-4 mr-1.5" />Add</Button>
      </div>

      {loading ? <div className="space-y-3">{Array.from({length:3}).map((_,i) => <Skeleton key={i} className="h-20 rounded-xl" />)}</div>
      : pubs.length === 0 ? (
        <div className="text-center py-20 text-muted-foreground border border-dashed rounded-xl">
          <Newspaper className="h-12 w-12 mx-auto mb-3 opacity-30" />
          <p>No publications archived yet</p>
          <Button variant="outline" className="mt-4" onClick={() => setOpen(true)}><Plus className="h-4 w-4 mr-1.5" />Add First</Button>
        </div>
      ) : (
        <div className="space-y-3">
          {pubs.map((pub) => (
            <div key={pub.id} className="group flex gap-4 p-4 bg-card border rounded-xl hover:shadow-sm transition-all">
              <Newspaper className="h-5 w-5 text-muted-foreground mt-0.5 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="font-medium bengali-text line-clamp-1">{pub.title}</p>
                <div className="flex flex-wrap items-center gap-2 mt-1 text-xs text-muted-foreground">
                  <span>{pub.newspaperName}</span>
                  {pub.publicationDate && <span>· {formatDate(pub.publicationDate)}</span>}
                  <Badge variant="outline" className="text-[10px]">{pub.category}</Badge>
                </div>
              </div>
              <button onClick={async () => { await deletePublication(pub.id); setPubs(pubs.filter(p => p.id !== pub.id)); }} className="opacity-0 group-hover:opacity-100 p-1.5 rounded-md hover:bg-destructive/10 text-destructive">
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Add Publication Record</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div><Label className="mb-1.5 block text-sm">Article Title *</Label>
            <Input value={form.title} onChange={(e) => setForm({...form, title: e.target.value})} placeholder="Article title..." className="bengali-text" /></div>
            <div><Label className="mb-1.5 block text-sm">Newspaper / Magazine *</Label>
            <Input value={form.newspaperName} onChange={(e) => setForm({...form, newspaperName: e.target.value})} placeholder="e.g. Prothom Alo" /></div>
            <div><Label className="mb-1.5 block text-sm">Publication Date</Label>
            <Input type="date" value={form.publicationDate} onChange={(e) => setForm({...form, publicationDate: e.target.value})} /></div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={handleAdd} disabled={saving || !form.title || !form.newspaperName}>Save</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
