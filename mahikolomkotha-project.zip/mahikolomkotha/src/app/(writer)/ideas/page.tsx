"use client";
import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { getWriterIdeas, createIdea, deleteIdea, updateIdeaStatus } from "@/lib/firebase/firestore";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Lightbulb, Plus, Trash2, CheckCircle } from "lucide-react";
import { formatRelativeDate } from "@/lib/utils";
import type { Idea } from "@/types";

export default function IdeasPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [ideas, setIdeas] = useState<Idea[]>([]);
  const [loading, setLoading] = useState(true);
  const [newIdea, setNewIdea] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!user) return;
    getWriterIdeas(user.uid).then((d) => { setIdeas(d); setLoading(false); });
  }, [user]);

  const handleAdd = async () => {
    if (!newIdea.trim() || !user) return;
    setSaving(true);
    try {
      const id = await createIdea(user.uid, newIdea.trim());
      const idea: Idea = { id, content: newIdea.trim(), authorId: user.uid, tags: [], status: "active", createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
      setIdeas([idea, ...ideas]);
      setNewIdea("");
    } finally { setSaving(false); }
  };

  const handleDelete = async (id: string) => {
    await deleteIdea(id);
    setIdeas(ideas.filter((i) => i.id !== id));
  };

  const handleMarkUsed = async (id: string) => {
    await updateIdeaStatus(id, "used");
    setIdeas(ideas.map((i) => i.id === id ? { ...i, status: "used" } : i));
  };

  const active = ideas.filter((i) => i.status === "active");
  const used   = ideas.filter((i) => i.status === "used");

  return (
    <div className="container mx-auto max-w-2xl px-4 py-6">
      <div className="flex items-center gap-3 mb-6">
        <Lightbulb className="h-6 w-6 text-primary" />
        <div>
          <h1 className="text-2xl font-bold bengali-heading">Idea Vault</h1>
          <p className="text-sm text-muted-foreground">Capture writing ideas before they vanish</p>
        </div>
      </div>

      {/* Quick capture */}
      <div className="bg-card border rounded-xl p-4 mb-6">
        <Textarea value={newIdea} onChange={(e) => setNewIdea(e.target.value)} placeholder="What's the idea? Write it in Bengali or English..." className="bengali-text resize-none mb-3" rows={3}
          onKeyDown={(e) => { if ((e.metaKey || e.ctrlKey) && e.key === "Enter") handleAdd(); }} />
        <div className="flex justify-between items-center">
          <p className="text-xs text-muted-foreground">Ctrl+Enter to save</p>
          <Button size="sm" onClick={handleAdd} disabled={saving || !newIdea.trim()}>
            <Plus className="h-4 w-4 mr-1.5" /> Capture Idea
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="space-y-3">{Array.from({length:3}).map((_,i) => <Skeleton key={i} className="h-20 rounded-xl" />)}</div>
      ) : (
        <>
          {active.length > 0 && (
            <div className="mb-6">
              <p className="text-sm font-semibold text-muted-foreground mb-3">Active Ideas ({active.length})</p>
              <div className="space-y-2">
                {active.map((idea) => (
                  <div key={idea.id} className="group flex gap-3 p-3 bg-card border rounded-lg hover:shadow-sm transition-all">
                    <p className="flex-1 text-sm bengali-text">{idea.content}</p>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                      <button onClick={() => handleMarkUsed(idea.id)} title="Mark as used" className="p-1.5 rounded-md hover:bg-green-100 text-green-600"><CheckCircle className="h-3.5 w-3.5" /></button>
                      <button onClick={() => handleDelete(idea.id)} title="Delete" className="p-1.5 rounded-md hover:bg-destructive/10 text-destructive"><Trash2 className="h-3.5 w-3.5" /></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {active.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <Lightbulb className="h-10 w-10 mx-auto mb-3 opacity-30" />
              <p>No active ideas. Capture one above!</p>
            </div>
          )}

          {used.length > 0 && (
            <div>
              <p className="text-sm font-semibold text-muted-foreground mb-3">Used Ideas ({used.length})</p>
              <div className="space-y-2 opacity-60">
                {used.map((idea) => (
                  <div key={idea.id} className="flex gap-3 p-3 bg-muted rounded-lg line-through">
                    <p className="flex-1 text-sm bengali-text">{idea.content}</p>
                    <button onClick={() => handleDelete(idea.id)} className="p-1.5 rounded-md hover:bg-destructive/10 text-destructive"><Trash2 className="h-3.5 w-3.5" /></button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
