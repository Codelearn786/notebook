"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { Loader2 } from "lucide-react";

export default function WriterLayout({ children }: { children: React.ReactNode }) {
  const { user, loading, canWrite } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !canWrite) {
      router.replace("/login");
    }
  }, [loading, canWrite, router]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-3 text-muted-foreground">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-sm">Loading...</p>
        </div>
      </div>
    );
  }

  if (!canWrite) return null;

  return <>{children}</>;
}
