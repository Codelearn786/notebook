"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter, useParams } from "next/navigation";
import { TipTapEditor } from "@/components/editor/TipTapEditor";
import { AIAssistant } from "@/components/ai/AIAssistant";
import { PublishModal, type PublishData } from "@/components/writer/PublishModal";
import { AutoSaveIndicator } from "@/components/shared/AutoSaveIndicator";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useAutoSave } from "@/hooks/useAutoSave";
import { useAuth } from "@/hooks/useAuth";
import {
  getDraft,
  autoSaveDraft,
  createArticle,
} from "@/lib/firebase/articles";
import { generateUniqueSlug, generateExcerpt } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Send, Save } from "lucide-react";
import type { Draft } from "@/types";

export default function EditDraftPage() {
  const params  = useParams<{ id: string }>();
  const router  = useRouter();
  const { user } = useAuth();
  const { toast } = useToast();

  const [draft,       setDraft]       = useState<Draft | null>(null);
  const [loading,     setLoading]     = useState(true);
  const [title,       setTitle]       = useState("");
  const [contentJSON, setContentJSON] = useState<Record<string, unknown>>({});
  const [contentHTML, setContentHTML] = useState("");
  const [aiOpen,      setAiOpen]      = useState(false);
  const [publishOpen, setPublishOpen] = useState(false);
  const [selectedText, setSelectedText] = useState("");

  const { status, lastSaved } = useAutoSave({
    draftId:     params.id,
    title,
    contentJSON,
    contentHTML,
    enabled:     !!params.id && !!user,
  });

  useEffect(() => {
    if (!params.id) return;
    getDraft(params.id).then((d) => {
      if (d) {
        setDraft(d);
        setTitle(d.title);
        setContentJSON(d.contentJSON);
      }
      setLoading(false);
    });
  }, [params.id]);

  const handleEditorChange = useCallback(
    (json: Record<string, unknown>, html: string) => {
      setContentJSON(json);
      setContentHTML(html);
    },
    []
  );

  const handlePublish = async (data: PublishData) => {
    if (!user) return;
    const slug = generateUniqueSlug(data.title);
    await createArticle({
      ...data,
      slug,
      contentJSON,
      contentHTML,
      excerpt: data.excerpt || generateExcerpt(contentHTML),
      authorId:    user.uid,
      authorName:  user.displayName,
      authorPhoto: user.photoURL,
      status:      "published",
      publishedAt: new Date().toISOString(),
      isPinned:    false,
    });
    toast({ title: "Published! 🎉" });
    router.push(data.type === "poem" ? `/poems/${slug}` : `/articles/${slug}`);
  };

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-6 space-y-4">
        <Skeleton className="h-9 w-full" />
        <Skeleton className="h-[60vh] w-full" />
      </div>
    );
  }

  if (!draft) {
    return (
      <div className="text-center py-20 text-muted-foreground">
        <p className="text-4xl mb-3">😕</p>
        <p>Draft not found.</p>
        <Button variant="outline" className="mt-4" onClick={() => router.push("/drafts")}>
          Back to Drafts
        </Button>
      </div>
    );
  }

  return (
    <div className="relative">
      {/* Top bar */}
      <div className="sticky top-14 z-30 flex items-center justify-between gap-3 px-4 py-2 border-b bg-background/95 backdrop-blur">
        <button onClick={() => router.back()} className="p-1.5 rounded-md hover:bg-accent text-muted-foreground">
          <ArrowLeft className="h-4 w-4" />
        </button>
        <Input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Article title..."
          className="flex-1 h-8 text-base font-semibold border-none shadow-none focus-visible:ring-0 px-0 bengali-text bg-transparent"
        />
        <div className="flex items-center gap-2">
          <AutoSaveIndicator status={status} lastSaved={lastSaved} />
          <Button
            size="sm"
            onClick={() => setPublishOpen(true)}
            disabled={!title.trim()}
          >
            <Send className="h-3.5 w-3.5 mr-1.5" />
            Publish
          </Button>
        </div>
      </div>

      <div className="max-w-3xl mx-auto">
        <TipTapEditor
          content={contentJSON}
          onChange={handleEditorChange}
          onAIOpen={() => {
            setSelectedText(window.getSelection()?.toString() || "");
            setAiOpen(true);
          }}
        />
      </div>

      <AIAssistant
        open={aiOpen}
        onClose={() => setAiOpen(false)}
        selectedText={selectedText}
        fullContent={contentHTML}
        onApply={() => {}}
      />

      {publishOpen && (
        <PublishModal
          open={publishOpen}
          onOpenChange={setPublishOpen}
          draftId={params.id}
          defaultTitle={title}
          contentHTML={contentHTML}
          onPublish={handlePublish}
        />
      )}
    </div>
  );
}
