"use client";

import { useState, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";
import { TipTapEditor } from "@/components/editor/TipTapEditor";
import { AIAssistant } from "@/components/ai/AIAssistant";
import { PublishModal, type PublishData } from "@/components/writer/PublishModal";
import { AutoSaveIndicator } from "@/components/shared/AutoSaveIndicator";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAutoSave } from "@/hooks/useAutoSave";
import { useAuth } from "@/hooks/useAuth";
import { saveDraft, createArticle, publishArticle } from "@/lib/firebase/articles";
import { generateUniqueSlug, generateExcerpt } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Sparkles, Send, ArrowLeft, Save } from "lucide-react";
import type { ContentType } from "@/types";

export default function StudioPage() {
  const router           = useRouter();
  const { user }         = useAuth();
  const { toast }        = useToast();

  const [title,        setTitle]        = useState("");
  const [contentJSON,  setContentJSON]  = useState<Record<string, unknown>>({});
  const [contentHTML,  setContentHTML]  = useState("");
  const [draftId,      setDraftId]      = useState<string | null>(null);
  const [aiOpen,       setAiOpen]       = useState(false);
  const [publishOpen,  setPublishOpen]  = useState(false);
  const [selectedText, setSelectedText] = useState("");
  const [saving,       setSaving]       = useState(false);

  const initRef = useRef(false);

  // Auto-save hook
  const { status, lastSaved } = useAutoSave({
    draftId,
    title,
    contentJSON,
    contentHTML,
    enabled: !!draftId && !!user,
  });

  const handleEditorChange = useCallback(
    (json: Record<string, unknown>, html: string) => {
      setContentJSON(json);
      setContentHTML(html);
    },
    []
  );

  // Create draft on first keypress
  const ensureDraft = useCallback(async () => {
    if (draftId || !user || initRef.current) return;
    initRef.current = true;
    try {
      const id = await saveDraft({
        title:        title || "Untitled",
        contentJSON,
        authorId:     user.uid,
        type:         "article",
        wordCount:    0,
        lastAutoSave: new Date().toISOString(),
        updatedAt:    new Date().toISOString(),
      });
      setDraftId(id);
    } catch {
      initRef.current = false;
    }
  }, [draftId, user, title, contentJSON]);

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTitle(e.target.value);
    ensureDraft();
  };

  const handleManualSave = async () => {
    if (!user) return;
    setSaving(true);
    try {
      if (!draftId) {
        const id = await saveDraft({
          title: title || "Untitled",
          contentJSON,
          authorId: user.uid,
          type: "article",
          wordCount: 0,
          lastAutoSave: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        });
        setDraftId(id);
        toast({ title: "Draft created" });
      } else {
        toast({ title: "Saved ✓" });
      }
    } finally {
      setSaving(false);
    }
  };

  const handlePublish = async (data: PublishData) => {
    if (!user) return;
    const slug = generateUniqueSlug(data.title);
    const articleId = await createArticle({
      ...data,
      slug,
      contentJSON,
      contentHTML,
      excerpt: data.excerpt || generateExcerpt(contentHTML),
      authorId:    user.uid,
      authorName:  user.displayName,
      authorPhoto: user.photoURL,
      status:      "published",
      publishedAt: new Date().toISOString(),
      tags:        data.tags,
      isPinned:    false,
    });
    toast({ title: "Published! 🎉" });
    router.push(data.type === "poem" ? `/poems/${slug}` : `/articles/${slug}`);
  };

  // Get selected text from editor for AI
  const getSelectedText = () => {
    const sel = window.getSelection();
    return sel ? sel.toString() : "";
  };

  const handleAIOpen = () => {
    setSelectedText(getSelectedText());
    setAiOpen(true);
  };

  const handleAIApply = (result: string) => {
    // The AI result is applied manually by the user copying it
    // For now just show it in the AI panel
  };

  return (
    <div className="relative">
      {/* Top bar */}
      <div className="sticky top-14 z-30 flex items-center justify-between gap-3 px-4 py-2 border-b bg-background/95 backdrop-blur">
        <button
          onClick={() => router.back()}
          className="p-1.5 rounded-md hover:bg-accent text-muted-foreground"
        >
          <ArrowLeft className="h-4 w-4" />
        </button>

        {/* Title input */}
        <Input
          value={title}
          onChange={handleTitleChange}
          placeholder="Article title..."
          className="flex-1 h-8 text-base font-semibold border-none shadow-none focus-visible:ring-0 px-0 bengali-text bg-transparent placeholder:text-muted-foreground/50"
        />

        <div className="flex items-center gap-2">
          <AutoSaveIndicator status={status} lastSaved={lastSaved} />
          <Button
            variant="outline"
            size="sm"
            onClick={handleManualSave}
            disabled={saving}
          >
            <Save className="h-3.5 w-3.5 mr-1.5" />
            Save Draft
          </Button>
          <Button
            size="sm"
            onClick={() => { ensureDraft(); setPublishOpen(true); }}
            disabled={!title.trim()}
          >
            <Send className="h-3.5 w-3.5 mr-1.5" />
            Publish
          </Button>
        </div>
      </div>

      {/* Editor */}
      <div className="max-w-3xl mx-auto">
        <TipTapEditor
          content={contentJSON}
          onChange={handleEditorChange}
          onSave={handleManualSave}
          onAIOpen={handleAIOpen}
        />
      </div>

      {/* AI Assistant panel */}
      <AIAssistant
        open={aiOpen}
        onClose={() => setAiOpen(false)}
        selectedText={selectedText}
        fullContent={contentHTML}
        onApply={handleAIApply}
      />

      {/* Publish modal */}
      {publishOpen && draftId && (
        <PublishModal
          open={publishOpen}
          onOpenChange={setPublishOpen}
          draftId={draftId}
          defaultTitle={title}
          contentHTML={contentHTML}
          onPublish={handlePublish}
        />
      )}
    </div>
  );
}
