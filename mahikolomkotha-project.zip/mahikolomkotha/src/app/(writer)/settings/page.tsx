"use client";

import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import {
  inviteWriter,
  getInvitedWriters,
  removeWriterInvite,
} from "@/lib/firebase/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Settings, UserPlus, Users, Trash2, Loader2, ShieldCheck } from "lucide-react";

interface InviteRecord {
  email:     string;
  invitedAt: string;
  status:    string;
}

export default function SettingsPage() {
  const { user, isAdmin } = useAuth();
  const { toast }         = useToast();

  const [newEmail,   setNewEmail]   = useState("");
  const [invites,    setInvites]    = useState<InviteRecord[]>([]);
  const [loading,    setLoading]    = useState(true);
  const [inviting,   setInviting]   = useState(false);

  useEffect(() => {
    if (!isAdmin) return;
    getInvitedWriters().then((data) => {
      setInvites(data as InviteRecord[]);
      setLoading(false);
    });
  }, [isAdmin]);

  const handleInvite = async () => {
    if (!newEmail.trim() || !user) return;
    setInviting(true);
    try {
      await inviteWriter(user.uid, newEmail.trim().toLowerCase());
      setInvites((prev) => [
        ...prev,
        { email: newEmail.trim().toLowerCase(), invitedAt: new Date().toISOString(), status: "pending" },
      ]);
      setNewEmail("");
      toast({ title: `Invite sent to ${newEmail}` });
    } catch {
      toast({ title: "Failed to invite", variant: "destructive" });
    } finally {
      setInviting(false);
    }
  };

  const handleRemove = async (email: string) => {
    if (!confirm(`Remove writer access for ${email}?`)) return;
    await removeWriterInvite(email);
    setInvites((prev) => prev.filter((i) => i.email !== email));
    toast({ title: "Writer access removed" });
  };

  if (!isAdmin) {
    return (
      <div className="text-center py-20 text-muted-foreground">
        <ShieldCheck className="h-12 w-12 mx-auto mb-3 opacity-30" />
        <p>Admin access required</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-2xl px-4 py-6">
      <div className="flex items-center gap-3 mb-8">
        <Settings className="h-6 w-6 text-primary" />
        <div>
          <h1 className="text-2xl font-bold bengali-heading">Settings</h1>
          <p className="text-sm text-muted-foreground">Admin panel</p>
        </div>
      </div>

      {/* Admin info */}
      <div className="bg-primary/5 border border-primary/20 rounded-xl p-4 mb-6 flex items-center gap-3">
        <ShieldCheck className="h-5 w-5 text-primary shrink-0" />
        <div>
          <p className="text-sm font-semibold">Admin Account</p>
          <p className="text-xs text-muted-foreground">{user?.email}</p>
        </div>
      </div>

      {/* Writer management */}
      <section>
        <div className="flex items-center gap-2 mb-4">
          <Users className="h-5 w-5 text-muted-foreground" />
          <h2 className="text-lg font-semibold">Writer Access</h2>
        </div>

        <p className="text-sm text-muted-foreground mb-4">
          Invite writers by email. They'll gain writer access when they sign in with that email address.
        </p>

        {/* Invite form */}
        <div className="bg-card border rounded-xl p-4 mb-5">
          <Label className="mb-2 block text-sm">Invite Writer by Email</Label>
          <div className="flex gap-2">
            <Input
              type="email"
              value={newEmail}
              onChange={(e) => setNewEmail(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") handleInvite(); }}
              placeholder="writer@example.com"
              className="flex-1"
            />
            <Button onClick={handleInvite} disabled={inviting || !newEmail.trim()}>
              {inviting ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <UserPlus className="h-4 w-4 mr-1.5" />
              )}
              Invite
            </Button>
          </div>
        </div>

        {/* Invite list */}
        {loading ? (
          <p className="text-sm text-muted-foreground">Loading...</p>
        ) : invites.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground border border-dashed rounded-xl">
            <Users className="h-8 w-8 mx-auto mb-2 opacity-30" />
            <p className="text-sm">No writers invited yet</p>
          </div>
        ) : (
          <div className="space-y-2">
            {invites.map((invite) => (
              <div
                key={invite.email}
                className="flex items-center justify-between p-3 bg-card border rounded-lg"
              >
                <div>
                  <p className="text-sm font-medium">{invite.email}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <Badge
                      variant={invite.status === "accepted" ? "default" : "secondary"}
                      className="text-xs"
                    >
                      {invite.status}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      Invited {new Date(invite.invitedAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => handleRemove(invite.email)}
                  className="p-1.5 rounded-md hover:bg-destructive/10 text-destructive transition-colors"
                  title="Remove access"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
