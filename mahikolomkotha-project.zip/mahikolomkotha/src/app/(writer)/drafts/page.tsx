"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { getWriterDrafts, deleteDraft } from "@/lib/firebase/articles";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { formatRelativeDate, countWords } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { PenSquare, Trash2, Clock, FileText, Plus } from "lucide-react";
import type { Draft } from "@/types";

export default function DraftsPage() {
  const { user } = useAuth();
  const router = useRouter();
  const { toast } = useToast();
  const [drafts, setDrafts] = useState<Draft[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    getWriterDrafts(user.uid).then((d) => { setDrafts(d); setLoading(false); });
  }, [user]);

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("Delete this draft?")) return;
    await deleteDraft(id);
    setDrafts((prev) => prev.filter((d) => d.id !== id));
    toast({ title: "Draft deleted" });
  };

  return (
    <div className="container mx-auto max-w-3xl px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold bengali-heading">My Drafts</h1>
          <p className="text-sm text-muted-foreground mt-0.5">{drafts.length} draft{drafts.length !== 1 ? "s" : ""}</p>
        </div>
        <Button size="sm" onClick={() => router.push("/studio")}>
          <Plus className="h-4 w-4 mr-1.5" /> New Article
        </Button>
      </div>

      {loading ? (
        <div className="space-y-3">{Array.from({length:4}).map((_,i) => <Skeleton key={i} className="h-24 w-full rounded-xl" />)}</div>
      ) : drafts.length === 0 ? (
        <div className="text-center py-20 text-muted-foreground">
          <FileText className="h-12 w-12 mx-auto mb-3 opacity-30" />
          <p className="font-medium">No drafts yet</p>
          <p className="text-sm mt-1">Start writing your first article</p>
          <Button className="mt-4" onClick={() => router.push("/studio")}>
            <Plus className="h-4 w-4 mr-1.5" /> Start Writing
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {drafts.map((draft) => (
            <div key={draft.id}
              onClick={() => router.push(`/studio/${draft.id}`)}
              className="group flex items-center gap-4 p-4 bg-card border rounded-xl hover:shadow-md cursor-pointer transition-all">
              <div className="flex-1 min-w-0">
                <h2 className="font-semibold line-clamp-1 bengali-text group-hover:text-primary transition-colors">
                  {draft.title || "Untitled Draft"}
                </h2>
                <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" /> {formatRelativeDate(draft.lastAutoSave)}
                  </span>
                  <span>{draft.wordCount || 0} words</span>
                </div>
              </div>
              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button size="icon" variant="ghost" className="h-8 w-8" onClick={(e) => { e.stopPropagation(); router.push(`/studio/${draft.id}`); }}>
                  <PenSquare className="h-3.5 w-3.5" />
                </Button>
                <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive hover:text-destructive" onClick={(e) => handleDelete(draft.id, e)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
