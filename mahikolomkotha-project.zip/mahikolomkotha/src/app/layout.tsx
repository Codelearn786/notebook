import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "./auth-provider";

export const metadata: Metadata = {
  title: { default: "মাহি কলম কথা — Bengali Literary Platform", template: "%s | মাহি কলম কথা" },
  description: "A digital home for Bengali literature — articles, poems, stories, and more.",
  keywords: ["Bengali", "literature", "poetry", "articles", "Bangla"],
  manifest: "/manifest.json",
  icons: { icon: "/icons/icon-192.png", apple: "/icons/icon-192.png" },
  openGraph: { type: "website", locale: "bn_BD", siteName: "মাহি কলম কথা", description: "A digital home for Bengali literature" },
};

export const viewport: Viewport = {
  themeColor: "#D97706", width: "device-width", initialScale: 1, maximumScale: 5,
  userScalable: true, viewportFit: "cover",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="bn" suppressHydrationWarning>
      <body className="antialiased">
        <AuthProvider>{children}</AuthProvider>
        <Toaster />
      </body>
    </html>
  );
}
