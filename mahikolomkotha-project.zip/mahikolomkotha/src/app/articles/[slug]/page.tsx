import { notFound } from "next/navigation";
import { getArticleBySlug } from "@/lib/firebase/articles";
import { ShareButtons } from "@/components/article/ShareButtons";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { formatDate } from "@/lib/utils";
import { Clock, Eye } from "lucide-react";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props) {
  const { slug } = await params;
  const article  = await getArticleBySlug(slug).catch(() => null);
  if (!article) return { title: "Not found" };
  return {
    title:       article.title,
    description: article.excerpt,
    openGraph: {
      title:       article.title,
      description: article.excerpt,
      images:      article.coverImage?.url ? [article.coverImage.url] : [],
    },
  };
}

export default async function ArticleDetailPage({ params }: Props) {
  const { slug } = await params;
  const article  = await getArticleBySlug(slug).catch(() => null);
  if (!article) notFound();

  return (
    <article className="container mx-auto max-w-3xl px-4 py-8">
      {/* Cover image */}
      {article.coverImage?.url && (
        <div className="aspect-[16/9] rounded-2xl overflow-hidden mb-8 shadow-sm">
          <img
            src={article.coverImage.url}
            alt={article.coverImage.alt}
            className="w-full h-full object-cover"
          />
        </div>
      )}

      {/* Header */}
      <header className="mb-8">
        <Badge variant="secondary" className="mb-3 text-xs capitalize">
          {article.type}
        </Badge>
        <h1 className="text-3xl md:text-4xl font-bold bengali-heading leading-tight mb-4">
          {article.title}
        </h1>
        <p className="text-lg text-muted-foreground bengali-text leading-relaxed mb-6">
          {article.excerpt}
        </p>

        {/* Author + meta */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={article.authorPhoto} />
              <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                {article.authorName?.[0]?.toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-semibold text-sm">{article.authorName}</p>
              <p className="text-xs text-muted-foreground">
                {formatDate(article.publishedAt || article.createdAt)}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5" />
              {article.stats.readTime} min read
            </span>
            <span className="flex items-center gap-1.5">
              <Eye className="h-3.5 w-3.5" />
              {article.stats.views.toLocaleString()} views
            </span>
          </div>
        </div>
      </header>

      {/* Body */}
      <div
        className="article-content mb-10"
        dangerouslySetInnerHTML={{ __html: article.contentHTML }}
      />

      {/* Tags */}
      {article.tags.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-8">
          {article.tags.map((tag) => (
            <Badge key={tag} variant="outline" className="text-xs">
              {tag}
            </Badge>
          ))}
        </div>
      )}

      {/* Share */}
      <div className="border-t pt-6">
        <ShareButtons title={article.title} slug={article.slug} type={article.type} />
      </div>
    </article>
  );
}
