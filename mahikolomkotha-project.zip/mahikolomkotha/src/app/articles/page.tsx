import { getPublishedArticles } from "@/lib/firebase/articles";
import { ArticleCard } from "@/components/article/ArticleCard";

export const revalidate = 60;
export default async function ArticlesPage() {
  let articles: import("@/types").Article[] = [];
  try { const result = await getPublishedArticles("article", 20); articles = result.articles; } catch {}
  return (
    <div className="container mx-auto max-w-screen-xl px-4 py-8">
      <h1 className="text-3xl font-bold bengali-heading mb-2">Articles</h1>
      <p className="text-muted-foreground mb-8">Essays, stories and features</p>
      {articles.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {articles.map((a) => <ArticleCard key={a.id} article={a} />)}
        </div>
      ) : (
        <div className="text-center py-20 text-muted-foreground">
          <p className="text-4xl mb-3">📰</p><p>No articles published yet.</p>
        </div>
      )}
    </div>
  );
}
