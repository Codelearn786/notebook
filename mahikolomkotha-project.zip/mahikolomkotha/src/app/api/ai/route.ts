import { NextRequest, NextResponse } from "next/server";
import Groq from "groq-sdk";

const groq = new Groq({
  apiKey: process.env.GROQ_API_KEY,
});

const SYSTEM_PROMPT = `You are a writing assistant specializing in Bengali literature and journalism. 
You help writers improve their Bengali and English content. 
When asked to work with Bengali text, respond in Bengali.
When asked to work with English text, respond in English.
If the content is mixed, match the primary language of the input.
Be creative, literary, and preserve the author's voice and style.
Always respond with just the requested content — no preambles, no "here is" phrases.`;

function buildPrompt(text: string, action: string): string {
  switch (action) {
    case "improve":
      return `Improve the following text for better grammar, flow, and literary quality. Keep the same meaning and language:\n\n${text}`;
    case "rewrite":
      return `Rewrite the following text with different phrasing but the same meaning:\n\n${text}`;
    case "expand":
      return `Expand the following text by adding more detail, context, and depth:\n\n${text}`;
    case "shorten":
      return `Shorten the following text while preserving the core message:\n\n${text}`;
    case "generate-title":
      return `Generate 3 compelling, catchy titles for this article/poem. Make them suitable for Bengali literature. If content is in Bengali, titles should be in Bengali:\n\n${text.slice(0, 2000)}`;
    case "generate-summary":
      return `Write a 2-3 sentence summary/excerpt for this article that would make readers want to read more:\n\n${text.slice(0, 3000)}`;
    case "facebook-caption":
      return `Write an engaging Facebook post caption for this article/poem. Include relevant emojis and make it shareable. Match the language of the content:\n\n${text.slice(0, 2000)}`;
    case "article-ideas":
      return `Based on this article/poem, suggest 5 related topics the writer could explore next. Be specific and creative:\n\n${text.slice(0, 2000)}`;
    default:
      return `Improve the following text:\n\n${text}`;
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { text, action } = body as { text: string; action: string };

    if (!text || typeof text !== "string") {
      return NextResponse.json(
        { success: false, error: "No text provided" },
        { status: 400 }
      );
    }

    if (!process.env.GROQ_API_KEY) {
      return NextResponse.json(
        { success: false, error: "AI service not configured" },
        { status: 503 }
      );
    }

    const prompt = buildPrompt(text, action);

    const completion = await groq.chat.completions.create({
      model:       "llama-3.3-70b-versatile",
      messages: [
        { role: "system",  content: SYSTEM_PROMPT },
        { role: "user",    content: prompt },
      ],
      max_tokens:  1500,
      temperature: 0.75,
    });

    const result = completion.choices[0]?.message?.content?.trim() ?? "";

    return NextResponse.json({ success: true, result });
  } catch (error: unknown) {
    console.error("Groq API error:", error);
    const message = error instanceof Error ? error.message : "AI request failed";
    return NextResponse.json(
      { success: false, error: message },
      { status: 500 }
    );
  }
}
