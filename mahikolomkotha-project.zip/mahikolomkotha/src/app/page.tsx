import { getPublishedArticles, getFeaturedArticles } from "@/lib/firebase/articles";
import { ArticleCard } from "@/components/article/ArticleCard";
import Link from "next/link";

export const revalidate = 60; // ISR - refresh every 60s

async function getHomeData() {
  try {
    const [featured, latest, poems] = await Promise.all([
      getFeaturedArticles(),
      getPublishedArticles("article", 6),
      getPublishedArticles("poem", 6),
    ]);
    return { featured, latest: latest.articles, poems: poems.articles };
  } catch {
    return { featured: [], latest: [], poems: [] };
  }
}

export default async function HomePage() {
  const { featured, latest, poems } = await getHomeData();

  return (
    <div className="container mx-auto max-w-screen-xl px-4">
      {/* Hero */}
      <section className="py-10 md:py-16 text-center">
        <h1 className="text-4xl md:text-6xl font-bold bengali-heading text-primary mb-3">
          মাহি কলম কথা
        </h1>
        <p className="text-lg text-muted-foreground max-w-xl mx-auto">
          A digital home for Bengali literature — articles, poems, stories, and heritage.
        </p>
        <div className="flex justify-center gap-3 mt-5">
          <Link href="/articles" className="px-5 py-2 rounded-full bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
            Read Articles
          </Link>
          <Link href="/poems" className="px-5 py-2 rounded-full border text-sm font-medium hover:bg-accent transition-colors">
            Read Poems
          </Link>
        </div>
      </section>

      {/* Featured articles */}
      {featured.length > 0 && (
        <section className="mb-12">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-xl font-bold bengali-heading">Featured</h2>
            <Link href="/articles" className="text-sm text-primary hover:underline">View all →</Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {featured.map((a) => <ArticleCard key={a.id} article={a} variant="featured" />)}
          </div>
        </section>
      )}

      {/* Latest articles + poems side by side */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
        {/* Articles */}
        <section className="lg:col-span-2">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-xl font-bold bengali-heading">Latest Articles</h2>
            <Link href="/articles" className="text-sm text-primary hover:underline">View all →</Link>
          </div>
          {latest.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {latest.map((a) => <ArticleCard key={a.id} article={a} />)}
            </div>
          ) : (
            <EmptyState emoji="📰" text="No articles yet. Check back soon!" />
          )}
        </section>

        {/* Poems sidebar */}
        <section>
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-xl font-bold bengali-heading">Poems</h2>
            <Link href="/poems" className="text-sm text-primary hover:underline">View all →</Link>
          </div>
          <div className="space-y-4">
            {poems.length > 0 ? poems.map((p) => (
              <ArticleCard key={p.id} article={p} variant="compact" />
            )) : (
              <EmptyState emoji="✍️" text="No poems yet." />
            )}
          </div>
        </section>
      </div>
    </div>
  );
}

function EmptyState({ emoji, text }: { emoji: string; text: string }) {
  return (
    <div className="text-center py-12 text-muted-foreground rounded-xl border border-dashed">
      <p className="text-3xl mb-2">{emoji}</p>
      <p className="text-sm">{text}</p>
    </div>
  );
}
