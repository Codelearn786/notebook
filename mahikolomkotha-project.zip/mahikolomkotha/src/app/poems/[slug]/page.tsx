import { notFound } from "next/navigation";
import { getArticleBySlug } from "@/lib/firebase/articles";
import { ShareButtons } from "@/components/article/ShareButtons";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { formatDate } from "@/lib/utils";
import { Clock } from "lucide-react";

interface Props { params: Promise<{ slug: string }> }

export async function generateMetadata({ params }: Props) {
  const { slug } = await params;
  const article = await getArticleBySlug(slug).catch(() => null);
  if (!article) return { title: "Not found" };
  return { title: article.title, description: article.excerpt };
}

export default async function PoemDetailPage({ params }: Props) {
  const { slug } = await params;
  const article  = await getArticleBySlug(slug).catch(() => null);
  if (!article) notFound();

  return (
    <article className="container mx-auto max-w-2xl px-4 py-8">
      {article.coverImage?.url && (
        <div className="aspect-[16/9] rounded-2xl overflow-hidden mb-8 shadow-sm">
          <img src={article.coverImage.url} alt={article.coverImage.alt} className="w-full h-full object-cover" />
        </div>
      )}
      <header className="mb-8 text-center">
        <Badge variant="secondary" className="mb-3 text-xs">Poem</Badge>
        <h1 className="text-3xl md:text-4xl font-bold bengali-heading leading-tight mb-4">{article.title}</h1>
        <div className="flex items-center justify-center gap-3">
          <Avatar className="h-8 w-8">
            <AvatarImage src={article.authorPhoto} />
            <AvatarFallback className="text-xs bg-primary/10 text-primary">{article.authorName?.[0]?.toUpperCase()}</AvatarFallback>
          </Avatar>
          <div className="text-left">
            <p className="text-sm font-semibold">{article.authorName}</p>
            <p className="text-xs text-muted-foreground">{formatDate(article.publishedAt || article.createdAt)}</p>
          </div>
        </div>
      </header>
      <div className="article-content poem-content mb-10 text-center" dangerouslySetInnerHTML={{ __html: article.contentHTML }} />
      <div className="border-t pt-6 flex justify-center">
        <ShareButtons title={article.title} slug={article.slug} type="poem" />
      </div>
    </article>
  );
}
