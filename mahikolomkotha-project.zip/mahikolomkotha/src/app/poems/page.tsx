import { getPublishedArticles } from "@/lib/firebase/articles";
import { ArticleCard } from "@/components/article/ArticleCard";
import type { Article } from "@/types";

export const revalidate = 60;
export default async function PoemsPage() {
  let poems: Article[] = [];
  try { const result = await getPublishedArticles("poem", 20); poems = result.articles; } catch {}
  return (
    <div className="container mx-auto max-w-screen-xl px-4 py-8">
      <h1 className="text-3xl font-bold bengali-heading mb-2">Poems</h1>
      <p className="text-muted-foreground mb-8">Bengali poetry and verses</p>
      {poems.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {poems.map((p) => <ArticleCard key={p.id} article={p} />)}
        </div>
      ) : (
        <div className="text-center py-20 text-muted-foreground">
          <p className="text-4xl mb-3">✍️</p><p>No poems published yet.</p>
        </div>
      )}
    </div>
  );
}
