"use client";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ArticleCard } from "@/components/article/ArticleCard";
import { Skeleton } from "@/components/ui/skeleton";
import { Search } from "lucide-react";
import { getPublishedArticles } from "@/lib/firebase/articles";
import type { Article } from "@/types";

export default function SearchPage() {
  const [query,   setQuery]   = useState("");
  const [results, setResults] = useState<Article[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    setLoading(true);
    setSearched(true);
    try {
      // Client-side search from all published articles
      const { articles } = await getPublishedArticles(undefined, 50);
      const q = query.toLowerCase();
      const filtered = articles.filter(
        (a) =>
          a.title.toLowerCase().includes(q) ||
          a.excerpt.toLowerCase().includes(q) ||
          a.tags.some((t) => t.toLowerCase().includes(q)) ||
          a.authorName.toLowerCase().includes(q)
      );
      setResults(filtered);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto max-w-screen-xl px-4 py-8">
      <h1 className="text-3xl font-bold bengali-heading mb-6">Search</h1>
      <form onSubmit={handleSearch} className="flex gap-3 mb-8 max-w-xl">
        <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search articles, poems, topics..." className="flex-1" autoFocus />
        <Button type="submit" disabled={loading}><Search className="h-4 w-4 mr-2" />Search</Button>
      </form>
      {loading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {Array.from({length:6}).map((_,i) => <Skeleton key={i} className="h-64 rounded-xl" />)}
        </div>
      )}
      {!loading && searched && results.length === 0 && (
        <div className="text-center py-16 text-muted-foreground">
          <p className="text-4xl mb-3">🔍</p><p>No results for "{query}"</p>
        </div>
      )}
      {!loading && results.length > 0 && (
        <>
          <p className="text-sm text-muted-foreground mb-4">{results.length} result{results.length !== 1 ? "s" : ""} for "{query}"</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {results.map((a) => <ArticleCard key={a.id} article={a} />)}
          </div>
        </>
      )}
      {!searched && (
        <div className="text-center py-16 text-muted-foreground">
          <Search className="h-12 w-12 mx-auto mb-3 opacity-30" />
          <p>Search across all articles and poems</p>
        </div>
      )}
    </div>
  );
}
