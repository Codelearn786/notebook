"use client";
import { useAuthProvider } from "@/hooks/useAuth";
import { Navbar } from "@/components/layout/Navbar";
import { MobileBottomNav } from "@/components/layout/MobileBottomNav";

export function AuthProvider({ children }: { children: React.ReactNode }) {
  useAuthProvider();
  return (
    <>
      <Navbar />
      <main className="min-h-[calc(100vh-56px)] pb-20 md:pb-0">
        {children}
      </main>
      <MobileBottomNav />
    </>
  );
}
