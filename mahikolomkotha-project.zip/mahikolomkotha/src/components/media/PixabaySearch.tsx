"use client";

import { useState, useCallback } from "react";
import Image from "next/image";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, X } from "lucide-react";

interface PixabayHit {
  id:           number;
  previewURL:   string;
  largeImageURL: string;
  webformatURL:  string;
  tags:          string;
  user:          string;
  imageWidth:    number;
  imageHeight:   number;
}

interface PixabaySearchProps {
  open:          boolean;
  onOpenChange:  (open: boolean) => void;
  onImageSelect: (url: string, alt: string) => void;
}

const SUGGESTIONS = ["nature", "books", "rain", "culture", "Bengal", "village", "festival", "river", "sunset", "flowers"];

export function PixabaySearch({ open, onOpenChange, onImageSelect }: PixabaySearchProps) {
  const [query,    setQuery]   = useState("");
  const [images,   setImages]  = useState<PixabayHit[]>([]);
  const [loading,  setLoading] = useState(false);
  const [error,    setError]   = useState("");
  const [page,     setPage]    = useState(1);
  const [total,    setTotal]   = useState(0);

  const search = useCallback(async (q: string, pg = 1) => {
    if (!q.trim()) return;
    setLoading(true);
    setError("");
    try {
      const key = process.env.NEXT_PUBLIC_PIXABAY_API_KEY;
      const res = await fetch(
        `https://pixabay.com/api/?key=${key}&q=${encodeURIComponent(q)}&image_type=photo&per_page=20&page=${pg}&safesearch=true`
      );
      const data = await res.json();
      if (pg === 1) {
        setImages(data.hits || []);
      } else {
        setImages((prev) => [...prev, ...(data.hits || [])]);
      }
      setTotal(data.totalHits || 0);
      setPage(pg);
    } catch {
      setError("Failed to search images. Please try again.");
    } finally {
      setLoading(false);
    }
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    search(query, 1);
  };

  const handleSelect = (image: PixabayHit) => {
    onImageSelect(image.largeImageURL, image.tags);
    onOpenChange(false);
    setImages([]);
    setQuery("");
  };

  const handleClose = () => {
    onOpenChange(false);
    setImages([]);
    setQuery("");
    setError("");
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-3xl max-h-[85vh] flex flex-col p-0">
        <DialogHeader className="px-4 pt-4 pb-3 border-b">
          <DialogTitle className="flex items-center gap-2">
            <Search className="h-5 w-5 text-primary" />
            Search Free Images (Pixabay)
          </DialogTitle>
        </DialogHeader>

        {/* Search form */}
        <div className="px-4 py-3 border-b">
          <form onSubmit={handleSearch} className="flex gap-2">
            <Input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search: books, culture, rain, river, festival..."
              className="flex-1"
            />
            <Button type="submit" disabled={loading} size="sm">
              {loading ? "Searching..." : "Search"}
            </Button>
          </form>

          {/* Suggestion chips */}
          {!images.length && (
            <div className="flex flex-wrap gap-1.5 mt-3">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => { setQuery(s); search(s, 1); }}
                  className="text-xs px-2.5 py-1 rounded-full border bg-secondary hover:bg-accent transition-colors"
                >
                  {s}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Results */}
        <div className="flex-1 overflow-y-auto px-4 py-3">
          {error && (
            <p className="text-sm text-destructive text-center py-8">{error}</p>
          )}

          {loading && images.length === 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {Array.from({ length: 12 }).map((_, i) => (
                <Skeleton key={i} className="aspect-[4/3] rounded-lg" />
              ))}
            </div>
          )}

          {images.length > 0 && (
            <>
              <p className="text-xs text-muted-foreground mb-3">
                {total.toLocaleString()} results — click to insert
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {images.map((img) => (
                  <button
                    key={img.id}
                    onClick={() => handleSelect(img)}
                    className="group relative aspect-[4/3] overflow-hidden rounded-lg border-2 border-transparent hover:border-primary focus:border-primary focus:outline-none transition-all"
                  >
                    <img
                      src={img.previewURL}
                      alt={img.tags}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                      <span className="text-white text-xs font-medium opacity-0 group-hover:opacity-100 transition-opacity bg-black/50 px-2 py-1 rounded">
                        Insert
                      </span>
                    </div>
                  </button>
                ))}
              </div>

              {images.length < total && (
                <div className="flex justify-center mt-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => search(query, page + 1)}
                    disabled={loading}
                  >
                    {loading ? "Loading..." : "Load More"}
                  </Button>
                </div>
              )}
            </>
          )}

          {!loading && images.length === 0 && query && (
            <div className="text-center py-12 text-muted-foreground">
              <p className="text-4xl mb-3">🔍</p>
              <p>No images found for "{query}"</p>
              <p className="text-sm mt-1">Try different keywords</p>
            </div>
          )}

          {!loading && !query && !images.length && (
            <div className="text-center py-12 text-muted-foreground">
              <p className="text-4xl mb-3">🖼️</p>
              <p className="text-sm">Search for free images to insert into your article</p>
              <p className="text-xs mt-1">Powered by Pixabay · All images are free to use</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
