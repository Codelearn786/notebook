"use client";
import { useState } from "react";
import { Copy, Check, MessageCircle } from "lucide-react";
import { facebookShareUrl, whatsappShareUrl, copyToClipboard } from "@/lib/utils";

interface ShareButtonsProps { title: string; slug: string; type: string; }

export function ShareButtons({ title, slug, type }: ShareButtonsProps) {
  const [copied, setCopied] = useState(false);
  const base = typeof window !== "undefined" ? window.location.origin : "";
  const path = type === "poem" ? `/poems/${slug}` : `/articles/${slug}`;
  const url  = `${base}${path}`;

  const handleCopy = async () => {
    await copyToClipboard(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="flex items-center gap-2">
      <span className="text-sm text-muted-foreground mr-1">Share:</span>
      <a href={facebookShareUrl(url)} target="_blank" rel="noopener noreferrer"
        className="inline-flex items-center justify-center h-9 w-9 rounded-full bg-[#1877F2]/10 text-[#1877F2] hover:bg-[#1877F2]/20 transition-colors font-bold text-xs" title="Share on Facebook">
        f
      </a>
      <a href={whatsappShareUrl(title, url)} target="_blank" rel="noopener noreferrer"
        className="inline-flex items-center justify-center h-9 w-9 rounded-full bg-[#25D366]/10 text-[#25D366] hover:bg-[#25D366]/20 transition-colors" title="Share on WhatsApp">
        <MessageCircle className="h-4 w-4" />
      </a>
      <button onClick={handleCopy} className="inline-flex items-center justify-center h-9 w-9 rounded-full bg-muted hover:bg-accent transition-colors" title="Copy link">
        {copied ? <Check className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
      </button>
      {copied && <span className="text-xs text-green-600">Copied!</span>}
    </div>
  );
}
