"use client";

import Link from "next/link";
import Image from "next/image";
import { Clock, Eye, Heart, MessageCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { formatDate, truncate } from "@/lib/utils";
import type { Article } from "@/types";

interface ArticleCardProps {
  article:   Article;
  variant?:  "default" | "featured" | "compact";
}

const TYPE_LABELS: Record<string, string> = {
  article:  "Article",
  poem:     "Poem",
  opinion:  "Opinion",
  feature:  "Feature",
  heritage: "Heritage",
};

const TYPE_COLORS: Record<string, string> = {
  article:  "secondary",
  poem:     "default",
  opinion:  "outline",
  feature:  "secondary",
  heritage: "default",
};

export function ArticleCard({ article, variant = "default" }: ArticleCardProps) {
  const href = article.type === "poem"
    ? `/poems/${article.slug}`
    : `/articles/${article.slug}`;

  if (variant === "compact") {
    return (
      <Link href={href} className="flex gap-3 group">
        {article.coverImage?.url && (
          <div className="w-20 h-16 rounded-lg overflow-hidden shrink-0">
            <img
              src={article.coverImage.url}
              alt={article.coverImage.alt}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform"
            />
          </div>
        )}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium leading-snug line-clamp-2 group-hover:text-primary transition-colors bengali-text">
            {article.title}
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            {article.stats.readTime} min · {formatDate(article.publishedAt || article.createdAt)}
          </p>
        </div>
      </Link>
    );
  }

  if (variant === "featured") {
    return (
      <Link href={href} className="group block relative overflow-hidden rounded-2xl shadow-sm hover:shadow-md transition-shadow">
        <div className="aspect-[16/9] bg-muted relative">
          {article.coverImage?.url ? (
            <img
              src={article.coverImage.url}
              alt={article.coverImage.alt}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-brand-200 to-brand-400 flex items-center justify-center">
              <span className="text-4xl">✍️</span>
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
            <Badge className="mb-2 text-xs bg-primary/80 border-0">
              {TYPE_LABELS[article.type]}
            </Badge>
            <h2 className="text-xl font-bold leading-snug bengali-heading line-clamp-2 mb-2">
              {article.title}
            </h2>
            <p className="text-sm text-white/80 line-clamp-2 bengali-text">
              {article.excerpt}
            </p>
            <div className="flex items-center gap-3 mt-3 text-xs text-white/70">
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {article.stats.readTime} min
              </div>
              <div className="flex items-center gap-1">
                <Eye className="h-3 w-3" />
                {article.stats.views.toLocaleString()}
              </div>
              <div className="flex items-center gap-1">
                <Heart className="h-3 w-3" />
                {article.stats.likes}
              </div>
            </div>
          </div>
        </div>
      </Link>
    );
  }

  // Default card
  return (
    <article className="group bg-card rounded-xl border overflow-hidden hover:shadow-md transition-all duration-200">
      {/* Cover image */}
      {article.coverImage?.url && (
        <Link href={href}>
          <div className="aspect-[16/9] overflow-hidden">
            <img
              src={article.coverImage.url}
              alt={article.coverImage.alt}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          </div>
        </Link>
      )}

      <div className="p-4">
        {/* Type badge */}
        <div className="flex items-center gap-2 mb-2">
          <Badge variant={TYPE_COLORS[article.type] as "default" | "secondary" | "outline"} className="text-xs">
            {TYPE_LABELS[article.type]}
          </Badge>
          {article.isFeatured && (
            <Badge variant="default" className="text-xs bg-primary/20 text-primary border-0">
              Featured
            </Badge>
          )}
        </div>

        {/* Title */}
        <Link href={href}>
          <h2 className="font-bold text-base leading-snug line-clamp-2 group-hover:text-primary transition-colors bengali-heading mb-1.5">
            {article.title}
          </h2>
        </Link>

        {/* Excerpt */}
        <p className="text-sm text-muted-foreground line-clamp-2 bengali-text mb-3">
          {article.excerpt}
        </p>

        {/* Author + stats */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Avatar className="h-6 w-6">
              <AvatarImage src={article.authorPhoto} />
              <AvatarFallback className="text-xs bg-primary/10 text-primary">
                {article.authorName?.[0]?.toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col">
              <span className="text-xs font-medium">{article.authorName}</span>
              <span className="text-[10px] text-muted-foreground">
                {formatDate(article.publishedAt || article.createdAt)}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 text-xs text-muted-foreground">
            <span className="flex items-center gap-0.5">
              <Clock className="h-3 w-3" /> {article.stats.readTime}m
            </span>
            <span className="flex items-center gap-0.5">
              <Heart className="h-3 w-3" /> {article.stats.likes}
            </span>
          </div>
        </div>
      </div>
    </article>
  );
}
