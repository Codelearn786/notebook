"use client";

import { type Editor } from "@tiptap/react";
import {
  Bold, Italic, Underline, Strikethrough,
  Heading1, Heading2, Heading3,
  AlignLeft, AlignCenter, AlignRight, AlignJustify,
  List, ListOrdered, Quote, Code, Link2, Image as ImageIcon,
  Video, Table as TableIcon, Undo, Redo, Highlighter,
  Sparkles, Type,
} from "lucide-react";
import { useState, useRef } from "react";
import { cn } from "@/lib/utils";
import { uploadEditorImage } from "@/lib/firebase/storage";
import { useAuth } from "@/hooks/useAuth";
import { PixabaySearch } from "@/components/media/PixabaySearch";

interface ToolbarProps {
  editor: Editor;
  onAIOpen?: () => void;
}

interface ToolbarButtonProps {
  onClick:    () => void;
  active?:    boolean;
  disabled?:  boolean;
  title:      string;
  children:   React.ReactNode;
  className?: string;
}

function ToolbarButton({ onClick, active, disabled, title, children, className }: ToolbarButtonProps) {
  return (
    <button
      onMouseDown={(e) => { e.preventDefault(); onClick(); }}
      title={title}
      disabled={disabled}
      className={cn(
        "inline-flex items-center justify-center h-8 w-8 rounded-md transition-colors text-sm",
        "hover:bg-accent disabled:opacity-40 disabled:cursor-not-allowed",
        active ? "bg-accent text-accent-foreground" : "text-muted-foreground hover:text-foreground",
        className
      )}
    >
      {children}
    </button>
  );
}

function ToolbarDivider() {
  return <div className="w-px h-5 bg-border mx-0.5" />;
}

export function EditorToolbar({ editor, onAIOpen }: ToolbarProps) {
  const [pixabayOpen,  setPixabayOpen]  = useState(false);
  const [uploading,    setUploading]    = useState(false);
  const [linkUrl,      setLinkUrl]      = useState("");
  const [showLink,     setShowLink]     = useState(false);
  const [showVideo,    setShowVideo]    = useState(false);
  const [videoUrl,     setVideoUrl]     = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { user }     = useAuth();

  const setLink = () => {
    if (!linkUrl) {
      editor.chain().focus().unsetLink().run();
      setShowLink(false);
      return;
    }
    editor.chain().focus().setLink({ href: linkUrl }).run();
    setLinkUrl("");
    setShowLink(false);
  };

  const handleImageUpload = async (file: File) => {
    if (!user) return;
    setUploading(true);
    try {
      const url = await uploadEditorImage(file, user.uid);
      editor.chain().focus().setImage({ src: url, alt: file.name }).run();
    } catch (err) {
      console.error("Image upload failed:", err);
    } finally {
      setUploading(false);
    }
  };

  const insertYoutube = () => {
    if (!videoUrl) return;
    editor.commands.setYoutubeVideo({ src: videoUrl });
    setVideoUrl("");
    setShowVideo(false);
  };

  return (
    <>
      <div className="sticky top-14 z-30 flex flex-wrap items-center gap-0.5 px-3 py-1.5 border-b bg-background/95 backdrop-blur overflow-x-auto">

        {/* Undo / Redo */}
        <ToolbarButton onClick={() => editor.chain().focus().undo().run()} disabled={!editor.can().undo()} title="Undo (Ctrl+Z)">
          <Undo className="h-3.5 w-3.5" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().redo().run()} disabled={!editor.can().redo()} title="Redo (Ctrl+Y)">
          <Redo className="h-3.5 w-3.5" />
        </ToolbarButton>

        <ToolbarDivider />

        {/* Text formatting */}
        <ToolbarButton onClick={() => editor.chain().focus().toggleBold().run()} active={editor.isActive("bold")} title="Bold (Ctrl+B)">
          <Bold className="h-3.5 w-3.5" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleItalic().run()} active={editor.isActive("italic")} title="Italic (Ctrl+I)">
          <Italic className="h-3.5 w-3.5" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleUnderline().run()} active={editor.isActive("underline")} title="Underline (Ctrl+U)">
          <Underline className="h-3.5 w-3.5" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleStrike().run()} active={editor.isActive("strike")} title="Strikethrough">
          <Strikethrough className="h-3.5 w-3.5" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleHighlight().run()} active={editor.isActive("highlight")} title="Highlight">
          <Highlighter className="h-3.5 w-3.5" />
        </ToolbarButton>

        <ToolbarDivider />

        {/* Headings */}
        <ToolbarButton onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()} active={editor.isActive("heading", { level: 1 })} title="Heading 1">
          <Heading1 className="h-3.5 w-3.5" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()} active={editor.isActive("heading", { level: 2 })} title="Heading 2">
          <Heading2 className="h-3.5 w-3.5" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()} active={editor.isActive("heading", { level: 3 })} title="Heading 3">
          <Heading3 className="h-3.5 w-3.5" />
        </ToolbarButton>

        <ToolbarDivider />

        {/* Alignment */}
        <ToolbarButton onClick={() => editor.chain().focus().setTextAlign("left").run()} active={editor.isActive({ textAlign: "left" })} title="Align Left">
          <AlignLeft className="h-3.5 w-3.5" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().setTextAlign("center").run()} active={editor.isActive({ textAlign: "center" })} title="Align Center">
          <AlignCenter className="h-3.5 w-3.5" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().setTextAlign("right").run()} active={editor.isActive({ textAlign: "right" })} title="Align Right">
          <AlignRight className="h-3.5 w-3.5" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().setTextAlign("justify").run()} active={editor.isActive({ textAlign: "justify" })} title="Justify">
          <AlignJustify className="h-3.5 w-3.5" />
        </ToolbarButton>

        <ToolbarDivider />

        {/* Lists */}
        <ToolbarButton onClick={() => editor.chain().focus().toggleBulletList().run()} active={editor.isActive("bulletList")} title="Bullet List">
          <List className="h-3.5 w-3.5" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleOrderedList().run()} active={editor.isActive("orderedList")} title="Numbered List">
          <ListOrdered className="h-3.5 w-3.5" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleBlockquote().run()} active={editor.isActive("blockquote")} title="Blockquote">
          <Quote className="h-3.5 w-3.5" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleCode().run()} active={editor.isActive("code")} title="Inline Code">
          <Code className="h-3.5 w-3.5" />
        </ToolbarButton>

        <ToolbarDivider />

        {/* Link */}
        <ToolbarButton onClick={() => setShowLink(!showLink)} active={editor.isActive("link") || showLink} title="Add Link">
          <Link2 className="h-3.5 w-3.5" />
        </ToolbarButton>

        {/* Image upload */}
        <ToolbarButton
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          title="Upload Image"
        >
          <ImageIcon className="h-3.5 w-3.5" />
        </ToolbarButton>

        {/* Pixabay image search */}
        <ToolbarButton onClick={() => setPixabayOpen(true)} title="Search Pixabay Images" className="text-xs font-bold px-1 w-auto">
          <span className="text-[10px] font-semibold">PX</span>
        </ToolbarButton>

        {/* Video embed */}
        <ToolbarButton onClick={() => setShowVideo(!showVideo)} active={showVideo} title="Embed YouTube Video">
          <Video className="h-3.5 w-3.5" />
        </ToolbarButton>

        {/* Table */}
        <ToolbarButton
          onClick={() => editor.chain().focus().insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run()}
          title="Insert Table"
        >
          <TableIcon className="h-3.5 w-3.5" />
        </ToolbarButton>

        <ToolbarDivider />

        {/* AI Assistant */}
        <button
          onMouseDown={(e) => { e.preventDefault(); onAIOpen?.(); }}
          title="AI Writing Assistant"
          className="inline-flex items-center gap-1 h-8 px-2.5 rounded-md text-xs font-medium bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
        >
          <Sparkles className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">AI</span>
        </button>
      </div>

      {/* Link input popover */}
      {showLink && (
        <div className="flex items-center gap-2 px-3 py-2 border-b bg-accent/30">
          <input
            autoFocus
            type="url"
            value={linkUrl}
            onChange={(e) => setLinkUrl(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") setLink(); if (e.key === "Escape") setShowLink(false); }}
            placeholder="https://example.com"
            className="flex-1 h-7 text-sm px-2 rounded border bg-background outline-none focus:ring-1 focus:ring-ring"
          />
          <button onClick={setLink} className="text-xs px-3 h-7 bg-primary text-primary-foreground rounded hover:bg-primary/90">
            Add
          </button>
          {editor.isActive("link") && (
            <button
              onClick={() => { editor.chain().focus().unsetLink().run(); setShowLink(false); }}
              className="text-xs px-3 h-7 border rounded hover:bg-accent"
            >
              Remove
            </button>
          )}
        </div>
      )}

      {/* Video URL input */}
      {showVideo && (
        <div className="flex items-center gap-2 px-3 py-2 border-b bg-accent/30">
          <input
            autoFocus
            type="url"
            value={videoUrl}
            onChange={(e) => setVideoUrl(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") insertYoutube(); if (e.key === "Escape") setShowVideo(false); }}
            placeholder="YouTube URL — https://youtube.com/watch?v=..."
            className="flex-1 h-7 text-sm px-2 rounded border bg-background outline-none focus:ring-1 focus:ring-ring"
          />
          <button onClick={insertYoutube} className="text-xs px-3 h-7 bg-primary text-primary-foreground rounded hover:bg-primary/90">
            Embed
          </button>
        </div>
      )}

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleImageUpload(file);
          e.target.value = "";
        }}
      />

      {/* Pixabay search modal */}
      <PixabaySearch
        open={pixabayOpen}
        onOpenChange={setPixabayOpen}
        onImageSelect={(url, alt) => {
          editor.chain().focus().setImage({ src: url, alt }).run();
        }}
      />
    </>
  );
}
