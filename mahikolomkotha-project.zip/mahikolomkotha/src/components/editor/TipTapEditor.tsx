"use client";

import { useEditor, EditorContent, type Editor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Image from "@tiptap/extension-image";
import TextAlign from "@tiptap/extension-text-align";
import Underline from "@tiptap/extension-underline";
import Placeholder from "@tiptap/extension-placeholder";
import Link from "@tiptap/extension-link";
import { Table } from "@tiptap/extension-table";
import { TableRow } from "@tiptap/extension-table-row";
import { TableCell } from "@tiptap/extension-table-cell";
import { TableHeader } from "@tiptap/extension-table-header";
import Youtube from "@tiptap/extension-youtube";
import Color from "@tiptap/extension-color";
import { TextStyle } from "@tiptap/extension-text-style";
import Highlight from "@tiptap/extension-highlight";
import CharacterCount from "@tiptap/extension-character-count";
import { useEffect, useCallback } from "react";
import { EditorToolbar } from "./EditorToolbar";

interface TipTapEditorProps {
  content:    Record<string, unknown>;
  onChange:   (json: Record<string, unknown>, html: string) => void;
  onSave?:    () => void;
  onAIOpen?:  () => void;
  editable?:  boolean;
  className?: string;
}

export function TipTapEditor({
  content,
  onChange,
  onSave,
  onAIOpen,
  editable = true,
  className,
}: TipTapEditorProps) {
  const editor = useEditor({
    immediatelyRender: false,
    editable,
    extensions: [
      StarterKit.configure({
        heading:  { levels: [1, 2, 3] },
        code:     { HTMLAttributes: { class: "rounded bg-muted px-1.5 py-0.5 font-mono text-sm" } },
        codeBlock: { HTMLAttributes: { class: "rounded-lg bg-muted p-4 font-mono text-sm my-4 overflow-x-auto" } },
        blockquote: { HTMLAttributes: { class: "" } },
      }),
      Underline,
      TextAlign.configure({
        types:            ["heading", "paragraph"],
        alignments:       ["left", "center", "right", "justify"],
        defaultAlignment: "justify",
      }),
      Link.configure({
        openOnClick:        false,
        autolink:           true,
        HTMLAttributes: {
          class:  "text-primary underline underline-offset-2 cursor-pointer",
          target: "_blank",
          rel:    "noopener noreferrer",
        },
      }),
      Image.configure({
        HTMLAttributes: { class: "rounded-lg max-w-full my-2 mx-auto" },
        allowBase64: true,
      }),
      Table.configure({ resizable: false }),
      TableRow,
      TableHeader,
      TableCell,
      Youtube.configure({
        controls: true,
        nocookie:  true,
        HTMLAttributes: { class: "w-full rounded-lg my-4", style: "aspect-ratio:16/9" },
      }),
      Color,
      TextStyle,
      Highlight.configure({ multicolor: true }),
      CharacterCount,
      Placeholder.configure({
        placeholder: ({ node }) => {
          if (node.type.name === "heading") return "Heading...";
          return "Start writing your article in Bengali or English...";
        },
        includeChildren: true,
      }),
    ],

    content: Object.keys(content).length ? content : "",

    onUpdate: ({ editor }) => {
      onChange(editor.getJSON() as Record<string, unknown>, editor.getHTML());
    },

    editorProps: {
      attributes: {
        class: "bengali-text focus:outline-none",
        spellcheck: "false",
      },
      handlePaste(view, event) {
        // Paste image from clipboard
        const items = Array.from(event.clipboardData?.items ?? []);
        const imageItem = items.find((i) => i.type.startsWith("image/"));
        if (imageItem) {
          event.preventDefault();
          const blob = imageItem.getAsFile();
          if (!blob) return false;
          const reader = new FileReader();
          reader.onload = (e) => {
            const src = e.target?.result as string;
            view.dispatch(
              view.state.tr.replaceSelectionWith(
                view.state.schema.nodes.image.create({ src })
              )
            );
          };
          reader.readAsDataURL(blob);
          return true;
        }
        return false;
      },
      handleDrop(view, event, _slice, moved) {
        if (moved) return false;
        const file = event.dataTransfer?.files[0];
        if (file?.type.startsWith("image/")) {
          event.preventDefault();
          const reader = new FileReader();
          reader.onload = (e) => {
            const src = e.target?.result as string;
            const pos  = view.posAtCoords({ left: event.clientX, top: event.clientY });
            if (!pos) return;
            view.dispatch(
              view.state.tr.insert(
                pos.pos,
                view.state.schema.nodes.image.create({ src })
              )
            );
          };
          reader.readAsDataURL(file);
          return true;
        }
        return false;
      },
    },
  });

  // Keyboard shortcut: Ctrl+S / Cmd+S
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "s") {
        e.preventDefault();
        onSave?.();
      }
    },
    [onSave]
  );

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [handleKeyDown]);

  // Sync external content changes (e.g., restoring from localStorage)
  useEffect(() => {
    if (!editor) return;
    if (
      Object.keys(content).length &&
      JSON.stringify(editor.getJSON()) !== JSON.stringify(content)
    ) {
      editor.commands.setContent(content);
    }
  }, []);  // eslint-disable-line react-hooks/exhaustive-deps

  if (!editor) return null;

  return (
    <div className={className}>
      {editable && <EditorToolbar editor={editor} onAIOpen={onAIOpen} />}
      <EditorContent
        editor={editor}
        className="min-h-[65vh]"
      />
      {editable && (
        <div className="flex justify-between items-center px-4 py-2 border-t text-xs text-muted-foreground">
          <span>
            {editor.storage.characterCount?.words() ?? 0} words ·{" "}
            {editor.storage.characterCount?.characters() ?? 0} characters
          </span>
          <span className="hidden sm:block">Ctrl+S to save · Bengali supported ✓</span>
        </div>
      )}
    </div>
  );
}

export type { Editor };
