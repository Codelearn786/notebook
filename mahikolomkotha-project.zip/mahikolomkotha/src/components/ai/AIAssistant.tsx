"use client";

import { useState } from "react";
import { Sparkles, X, Copy, Check, RefreshCw, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { type AIAction } from "@/types";

interface AIAssistantProps {
  open:           boolean;
  onClose:        () => void;
  selectedText:   string;
  fullContent:    string;
  onApply:        (result: string) => void;
}

const TEXT_ACTIONS: { action: AIAction; label: string; desc: string; icon: string }[] = [
  { action: "improve",  label: "Improve Writing",  desc: "Better grammar & style",     icon: "✨" },
  { action: "rewrite",  label: "Rewrite",          desc: "Different phrasing",         icon: "🔄" },
  { action: "expand",   label: "Expand",           desc: "Add more detail",            icon: "📝" },
  { action: "shorten",  label: "Make Shorter",     desc: "More concise",               icon: "✂️" },
];

const DOC_ACTIONS: { action: AIAction; label: string; desc: string; icon: string }[] = [
  { action: "generate-title",    label: "Generate Title",     desc: "Catchy Bengali/English title",    icon: "📰" },
  { action: "generate-summary",  label: "Generate Summary",   desc: "2–3 line excerpt",               icon: "📋" },
  { action: "facebook-caption",  label: "Facebook Caption",   desc: "Shareable social post",          icon: "📢" },
  { action: "article-ideas",     label: "More Ideas",         desc: "Related topics to write about",  icon: "💡" },
];

export function AIAssistant({ open, onClose, selectedText, fullContent, onApply }: AIAssistantProps) {
  const [result,   setResult]   = useState("");
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState("");
  const [lastAct,  setLastAct]  = useState<AIAction | null>(null);
  const [copied,   setCopied]   = useState(false);

  const callAI = async (action: AIAction) => {
    const text = action.startsWith("generate") || action === "facebook-caption" || action === "article-ideas"
      ? fullContent
      : selectedText || fullContent;

    if (!text.trim()) {
      setError("Please write some content first, or select text to improve.");
      return;
    }

    setLoading(true);
    setError("");
    setResult("");
    setLastAct(action);

    try {
      const res = await fetch("/api/ai", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ text, action }),
      });

      if (!res.ok) throw new Error(`Error ${res.status}`);
      const data = await res.json();

      if (data.success) {
        setResult(data.result);
      } else {
        setError(data.error || "AI request failed.");
      }
    } catch (err) {
      setError("Could not connect to AI. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleApply = () => {
    onApply(result);
    setResult("");
    onClose();
  };

  if (!open) return null;

  return (
    <>
      {/* Backdrop (mobile) */}
      <div
        className="fixed inset-0 z-40 bg-black/30 md:hidden"
        onClick={onClose}
      />

      {/* Panel */}
      <div className={cn(
        "fixed z-50 bg-background border shadow-xl flex flex-col",
        // Mobile: bottom sheet
        "bottom-0 left-0 right-0 rounded-t-2xl max-h-[80vh]",
        // Desktop: right sidebar
        "md:bottom-0 md:top-14 md:right-0 md:left-auto md:w-80 md:rounded-none md:rounded-l-xl md:max-h-none md:h-[calc(100vh-56px)]",
        "animate-slide-up md:animate-slide-in-right"
      )}>
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="font-semibold text-sm">AI Writing Assistant</span>
          </div>
          <button onClick={onClose} className="p-1 rounded-md hover:bg-accent">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4">
          {/* Context indicator */}
          {selectedText && (
            <div className="bg-accent/50 rounded-lg p-2.5 text-xs text-muted-foreground">
              <span className="font-medium text-foreground">Selected: </span>
              {selectedText.slice(0, 100)}{selectedText.length > 100 ? "…" : ""}
            </div>
          )}

          {/* Text actions */}
          {selectedText && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
                Selection Actions
              </p>
              <div className="grid grid-cols-2 gap-2">
                {TEXT_ACTIONS.map(({ action, label, desc, icon }) => (
                  <button
                    key={action}
                    onClick={() => callAI(action)}
                    disabled={loading}
                    className={cn(
                      "flex flex-col items-start p-2.5 rounded-lg border text-left transition-colors",
                      "hover:bg-accent hover:border-primary/30 disabled:opacity-50",
                      lastAct === action && loading ? "bg-accent border-primary/30" : ""
                    )}
                  >
                    <span className="text-base mb-0.5">{icon}</span>
                    <span className="text-xs font-medium">{label}</span>
                    <span className="text-[10px] text-muted-foreground">{desc}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Document actions */}
          <div>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
              Document Actions
            </p>
            <div className="grid grid-cols-2 gap-2">
              {DOC_ACTIONS.map(({ action, label, desc, icon }) => (
                <button
                  key={action}
                  onClick={() => callAI(action)}
                  disabled={loading}
                  className={cn(
                    "flex flex-col items-start p-2.5 rounded-lg border text-left transition-colors",
                    "hover:bg-accent hover:border-primary/30 disabled:opacity-50",
                    lastAct === action && loading ? "bg-accent border-primary/30" : ""
                  )}
                >
                  <span className="text-base mb-0.5">{icon}</span>
                  <span className="text-xs font-medium">{label}</span>
                  <span className="text-[10px] text-muted-foreground">{desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Loading */}
          {loading && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground bg-accent/30 rounded-lg p-3">
              <RefreshCw className="h-4 w-4 animate-spin text-primary" />
              <span>Thinking in Bengali/English…</span>
            </div>
          )}

          {/* Error */}
          {error && !loading && (
            <div className="bg-destructive/10 text-destructive text-sm rounded-lg p-3">
              {error}
            </div>
          )}

          {/* Result */}
          {result && !loading && (
            <div className="border rounded-lg overflow-hidden">
              <div className="flex items-center justify-between px-3 py-2 bg-accent/30 border-b">
                <span className="text-xs font-semibold text-primary">AI Result</span>
                <div className="flex gap-1">
                  <button
                    onClick={handleCopy}
                    className="text-xs flex items-center gap-1 px-2 py-1 rounded hover:bg-accent"
                  >
                    {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                    {copied ? "Copied" : "Copy"}
                  </button>
                  <button
                    onClick={() => lastAct && callAI(lastAct)}
                    className="text-xs flex items-center gap-1 px-2 py-1 rounded hover:bg-accent"
                  >
                    <RefreshCw className="h-3 w-3" /> Retry
                  </button>
                </div>
              </div>
              <div className="p-3 text-sm bengali-text whitespace-pre-wrap max-h-60 overflow-y-auto">
                {result}
              </div>
              {(lastAct === "improve" || lastAct === "rewrite" || lastAct === "expand" || lastAct === "shorten") && (
                <div className="px-3 py-2 border-t bg-accent/10">
                  <Button size="sm" className="w-full text-xs" onClick={handleApply}>
                    Apply to Editor
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
