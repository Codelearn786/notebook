"use client";

import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";
import {
  PenSquare,
  LogOut,
  Settings,
  FileText,
  Lightbulb,
  Archive,
  User,
  Menu,
  X,
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/hooks/useAuth";
import { signOut } from "@/lib/firebase/auth";
import { useAuthStore } from "@/stores/authStore";
import { cn } from "@/lib/utils";

export function Navbar() {
  const { user, loading, canWrite, isAdmin } = useAuth();
  const { reset } = useAuthStore();
  const router   = useRouter();
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    reset();
    router.push("/");
  };

  const initials = user?.displayName
    ?.split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2) || "U";

  const navLinks = [
    { href: "/",        label: "Home" },
    { href: "/articles", label: "Articles" },
    { href: "/poems",    label: "Poems" },
    { href: "/search",   label: "Search" },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 max-w-screen-xl items-center px-4 mx-auto">

        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 mr-6">
          <span className="text-xl font-bold text-primary bengali-heading">
            মাহি কলম কথা
          </span>
        </Link>

        {/* Desktop nav links */}
        <nav className="hidden md:flex items-center gap-1 flex-1">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={cn(
                "px-3 py-1.5 text-sm rounded-md transition-colors hover:bg-accent",
                pathname === link.href
                  ? "bg-accent text-accent-foreground font-medium"
                  : "text-muted-foreground"
              )}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Right side */}
        <div className="ml-auto flex items-center gap-2">
          {!loading && (
            <>
              {canWrite && (
                <Button
                  size="sm"
                  className="hidden md:inline-flex gap-1.5"
                  onClick={() => router.push("/studio")}
                >
                  <PenSquare className="h-4 w-4" />
                  Write
                </Button>
              )}

              {user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="outline-none rounded-full">
                      <Avatar className="h-8 w-8 cursor-pointer ring-2 ring-transparent hover:ring-primary/30 transition-all">
                        <AvatarImage src={user.photoURL} />
                        <AvatarFallback className="bg-primary/10 text-primary text-xs">
                          {initials}
                        </AvatarFallback>
                      </Avatar>
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-52">
                    <DropdownMenuLabel className="font-normal">
                      <div className="flex flex-col space-y-1">
                        <p className="text-sm font-medium">{user.displayName}</p>
                        <p className="text-xs text-muted-foreground">{user.email}</p>
                        <p className="text-xs text-primary capitalize">{user.role}</p>
                      </div>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    {canWrite && (
                      <>
                        <DropdownMenuItem onClick={() => router.push("/studio")}>
                          <PenSquare className="mr-2 h-4 w-4" /> New Article
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => router.push("/drafts")}>
                          <FileText className="mr-2 h-4 w-4" /> My Drafts
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => router.push("/ideas")}>
                          <Lightbulb className="mr-2 h-4 w-4" /> Ideas
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => router.push("/archive")}>
                          <Archive className="mr-2 h-4 w-4" /> Archive
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                      </>
                    )}
                    {isAdmin && (
                      <DropdownMenuItem onClick={() => router.push("/settings")}>
                        <Settings className="mr-2 h-4 w-4" /> Settings
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem
                      onClick={handleSignOut}
                      className="text-destructive focus:text-destructive"
                    >
                      <LogOut className="mr-2 h-4 w-4" /> Sign Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Button size="sm" onClick={() => router.push("/login")}>
                  Sign In
                </Button>
              )}

              {/* Mobile menu button */}
              <button
                className="md:hidden p-2 rounded-md hover:bg-accent"
                onClick={() => setMobileOpen(!mobileOpen)}
              >
                {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </>
          )}
        </div>
      </div>

      {/* Mobile nav */}
      {mobileOpen && (
        <div className="md:hidden border-t bg-background px-4 py-3 space-y-1">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setMobileOpen(false)}
              className={cn(
                "flex items-center px-3 py-2 rounded-md text-sm transition-colors",
                pathname === link.href
                  ? "bg-accent font-medium"
                  : "hover:bg-accent text-muted-foreground"
              )}
            >
              {link.label}
            </Link>
          ))}
        </div>
      )}
    </header>
  );
}
