"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, PenSquare, FileText, Lightbulb, Archive } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/useAuth";

const readerNav = [
  { href: "/",         icon: Home,       label: "Home" },
  { href: "/articles", icon: FileText,   label: "Articles" },
  { href: "/search",   icon: FileText,   label: "Search" },
];

const writerNav = [
  { href: "/",        icon: Home,       label: "Home" },
  { href: "/studio",  icon: PenSquare,  label: "Write" },
  { href: "/drafts",  icon: FileText,   label: "Drafts" },
  { href: "/ideas",   icon: Lightbulb,  label: "Ideas" },
  { href: "/archive", icon: Archive,    label: "Archive" },
];

export function MobileBottomNav() {
  const pathname  = usePathname();
  const { canWrite } = useAuth();
  const navItems = canWrite ? writerNav : readerNav;

  // Hide on studio/edit pages (full-screen editor)
  if (pathname.startsWith("/studio")) return null;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 md:hidden border-t bg-background/95 backdrop-blur">
      <div className="flex items-center justify-around pb-safe">
        {navItems.map(({ href, icon: Icon, label }) => {
          const active =
            href === "/" ? pathname === "/" : pathname.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex flex-col items-center justify-center gap-0.5 py-2 px-3 min-w-[60px] transition-colors",
                active ? "text-primary" : "text-muted-foreground hover:text-foreground"
              )}
            >
              <Icon
                className={cn(
                  "h-5 w-5 transition-transform",
                  active && "scale-110"
                )}
              />
              <span className="text-[10px] font-medium">{label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
