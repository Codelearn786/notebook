"use client";

import { Cloud, CloudOff, Loader2, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";
import type { SaveStatus } from "@/hooks/useAutoSave";

interface AutoSaveIndicatorProps {
  status:     SaveStatus;
  lastSaved?: Date | null;
  className?: string;
}

export function AutoSaveIndicator({ status, lastSaved, className }: AutoSaveIndicatorProps) {
  const items = {
    idle: {
      icon:  <Cloud className="h-3.5 w-3.5" />,
      text:  lastSaved ? `Saved ${formatTime(lastSaved)}` : "Auto-save on",
      color: "text-muted-foreground",
    },
    saving: {
      icon:  <Loader2 className="h-3.5 w-3.5 animate-spin" />,
      text:  "Saving…",
      color: "text-muted-foreground",
    },
    saved: {
      icon:  <CheckCircle2 className="h-3.5 w-3.5" />,
      text:  "Saved",
      color: "text-green-600 dark:text-green-500",
    },
    error: {
      icon:  <CloudOff className="h-3.5 w-3.5" />,
      text:  "Save failed",
      color: "text-destructive",
    },
  };

  const { icon, text, color } = items[status];

  return (
    <div className={cn("flex items-center gap-1.5 text-xs", color, className)}>
      {icon}
      <span>{text}</span>
    </div>
  );
}

function formatTime(date: Date): string {
  const now  = new Date();
  const diff = now.getTime() - date.getTime();
  const secs = Math.floor(diff / 1000);
  if (secs < 60) return "just now";
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}
