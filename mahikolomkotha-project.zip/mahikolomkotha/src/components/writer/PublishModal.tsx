"use client";

import { useState, useRef } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { uploadCoverImage } from "@/lib/firebase/storage";
import { useAuth } from "@/hooks/useAuth";
import { generateExcerpt } from "@/lib/utils";
import { ImageIcon, X, Loader2 } from "lucide-react";
import type { ContentType, Article } from "@/types";

interface PublishModalProps {
  open:          boolean;
  onOpenChange:  (open: boolean) => void;
  draftId:       string;
  defaultTitle:  string;
  contentHTML:   string;
  onPublish:     (data: PublishData) => Promise<void>;
}

export interface PublishData {
  title:       string;
  excerpt:     string;
  type:        ContentType;
  tags:        string[];
  coverImage?: { url: string; alt: string; storageRef?: string };
  isFeatured:  boolean;
}

const CONTENT_TYPES: { value: ContentType; label: string; emoji: string }[] = [
  { value: "article",  label: "Article",   emoji: "📰" },
  { value: "poem",     label: "Poem",      emoji: "✍️" },
  { value: "opinion",  label: "Opinion",   emoji: "💬" },
  { value: "feature",  label: "Feature",   emoji: "🌟" },
  { value: "heritage", label: "Heritage",  emoji: "🏛️" },
];

export function PublishModal({
  open, onOpenChange, draftId, defaultTitle, contentHTML, onPublish,
}: PublishModalProps) {
  const { user, isAdmin } = useAuth();
  const [title,       setTitle]       = useState(defaultTitle);
  const [excerpt,     setExcerpt]     = useState(generateExcerpt(contentHTML, 200));
  const [type,        setType]        = useState<ContentType>("article");
  const [tagInput,    setTagInput]    = useState("");
  const [tags,        setTags]        = useState<string[]>([]);
  const [coverUrl,    setCoverUrl]    = useState("");
  const [uploading,   setUploading]   = useState(false);
  const [isFeatured,  setIsFeatured]  = useState(false);
  const [publishing,  setPublishing]  = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleCoverUpload = async (file: File) => {
    if (!user) return;
    setUploading(true);
    try {
      const url = await uploadCoverImage(file, user.uid, draftId);
      setCoverUrl(url);
    } finally {
      setUploading(false);
    }
  };

  const addTag = () => {
    const t = tagInput.trim();
    if (t && !tags.includes(t) && tags.length < 8) {
      setTags([...tags, t]);
      setTagInput("");
    }
  };

  const handlePublish = async () => {
    if (!title.trim()) return;
    setPublishing(true);
    try {
      await onPublish({
        title: title.trim(),
        excerpt: excerpt.trim() || generateExcerpt(contentHTML),
        type,
        tags,
        coverImage: coverUrl ? { url: coverUrl, alt: title } : undefined,
        isFeatured,
      });
      onOpenChange(false);
    } finally {
      setPublishing(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            🚀 Publish Article
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Cover image */}
          <div>
            <Label className="mb-1.5 block">Cover Image</Label>
            {coverUrl ? (
              <div className="relative aspect-[16/9] rounded-lg overflow-hidden">
                <img src={coverUrl} alt="Cover" className="w-full h-full object-cover" />
                <button
                  onClick={() => setCoverUrl("")}
                  className="absolute top-2 right-2 bg-black/50 text-white rounded-full p-1 hover:bg-black/70"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => fileRef.current?.click()}
                disabled={uploading}
                className="w-full aspect-[16/9] rounded-lg border-2 border-dashed border-border hover:border-primary/40 flex flex-col items-center justify-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
              >
                {uploading ? (
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                ) : (
                  <>
                    <ImageIcon className="h-8 w-8" />
                    <span className="text-sm">Click to upload cover image</span>
                  </>
                )}
              </button>
            )}
            <input ref={fileRef} type="file" accept="image/*" className="hidden"
              onChange={(e) => { const f = e.target.files?.[0]; if (f) handleCoverUpload(f); e.target.value = ""; }} />
          </div>

          {/* Title */}
          <div>
            <Label htmlFor="pub-title" className="mb-1.5 block">Title *</Label>
            <Input
              id="pub-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Article title..."
              className="bengali-text"
            />
          </div>

          {/* Excerpt */}
          <div>
            <Label htmlFor="pub-excerpt" className="mb-1.5 block">Excerpt / Summary</Label>
            <Textarea
              id="pub-excerpt"
              value={excerpt}
              onChange={(e) => setExcerpt(e.target.value)}
              rows={3}
              placeholder="Short summary shown in article listings..."
              className="bengali-text resize-none"
            />
          </div>

          {/* Content type */}
          <div>
            <Label className="mb-1.5 block">Content Type</Label>
            <div className="flex flex-wrap gap-2">
              {CONTENT_TYPES.map((ct) => (
                <button
                  key={ct.value}
                  onClick={() => setType(ct.value)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-sm transition-colors ${
                    type === ct.value
                      ? "bg-primary text-primary-foreground border-primary"
                      : "hover:bg-accent"
                  }`}
                >
                  {ct.emoji} {ct.label}
                </button>
              ))}
            </div>
          </div>

          {/* Tags */}
          <div>
            <Label className="mb-1.5 block">Tags</Label>
            <div className="flex gap-2">
              <Input
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" || e.key === ",") { e.preventDefault(); addTag(); } }}
                placeholder="Add tag (press Enter)"
                className="flex-1 text-sm"
              />
              <Button type="button" variant="outline" size="sm" onClick={addTag}>Add</Button>
            </div>
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-2">
                {tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="cursor-pointer hover:line-through"
                    onClick={() => setTags(tags.filter((t) => t !== tag))}>
                    {tag} ×
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Featured toggle (admin only) */}
          {isAdmin && (
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsFeatured(!isFeatured)}
                className={`relative w-10 h-5 rounded-full transition-colors ${isFeatured ? "bg-primary" : "bg-muted"}`}
              >
                <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-transform ${isFeatured ? "translate-x-5" : "translate-x-0.5"}`} />
              </button>
              <Label className="cursor-pointer" onClick={() => setIsFeatured(!isFeatured)}>
                Feature on Home Page
              </Label>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={publishing}>
            Cancel
          </Button>
          <Button onClick={handlePublish} disabled={publishing || !title.trim()}>
            {publishing ? <><Loader2 className="h-4 w-4 animate-spin mr-2" />Publishing…</> : "🚀 Publish"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
