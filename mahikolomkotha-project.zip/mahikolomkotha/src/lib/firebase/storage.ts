"use client";

import {
  ref,
  uploadBytesResumable,
  getDownloadURL,
  deleteObject,
  type StorageReference,
} from "firebase/storage";
import { storage } from "./config";

export type UploadProgress = {
  progress: number;
  url?: string;
  error?: string;
};

// ── Upload image with progress ────────────────────────────────
export async function uploadImage(
  file: File,
  path: string,
  onProgress?: (progress: number) => void
): Promise<string> {
  // Validate file type
  if (!file.type.startsWith("image/")) {
    throw new Error("File must be an image");
  }
  // Validate file size (5MB max)
  if (file.size > 5 * 1024 * 1024) {
    throw new Error("Image must be smaller than 5MB");
  }

  const storageRef = ref(storage, path);
  const metadata   = { contentType: file.type };

  return new Promise((resolve, reject) => {
    const uploadTask = uploadBytesResumable(storageRef, file, metadata);

    uploadTask.on(
      "state_changed",
      (snapshot) => {
        const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        onProgress?.(Math.round(progress));
      },
      (error) => reject(error),
      async () => {
        const url = await getDownloadURL(uploadTask.snapshot.ref);
        resolve(url);
      }
    );
  });
}

// ── Upload PDF ────────────────────────────────────────────────
export async function uploadPDF(
  file: File,
  authorId: string,
  onProgress?: (progress: number) => void
): Promise<string> {
  if (file.type !== "application/pdf") {
    throw new Error("File must be a PDF");
  }
  if (file.size > 10 * 1024 * 1024) {
    throw new Error("PDF must be smaller than 10MB");
  }

  const filename   = `${Date.now()}_${file.name.replace(/\s/g, "_")}`;
  const path       = `publications/${authorId}/${filename}`;
  const storageRef = ref(storage, path);

  return new Promise((resolve, reject) => {
    const uploadTask = uploadBytesResumable(storageRef, file, {
      contentType: "application/pdf",
    });

    uploadTask.on(
      "state_changed",
      (snapshot) => {
        const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        onProgress?.(Math.round(progress));
      },
      reject,
      async () => {
        const url = await getDownloadURL(uploadTask.snapshot.ref);
        resolve(url);
      }
    );
  });
}

// ── Upload cover image ────────────────────────────────────────
export async function uploadCoverImage(
  file: File,
  authorId: string,
  articleId: string,
  onProgress?: (progress: number) => void
): Promise<string> {
  const ext  = file.name.split(".").pop() || "jpg";
  const path = `articles/${authorId}/${articleId}/cover.${ext}`;
  return uploadImage(file, path, onProgress);
}

// ── Upload inline editor image ────────────────────────────────
export async function uploadEditorImage(
  file: File,
  authorId: string,
  onProgress?: (progress: number) => void
): Promise<string> {
  const ext  = file.name.split(".").pop() || "jpg";
  const path = `articles/${authorId}/media/${Date.now()}.${ext}`;
  return uploadImage(file, path, onProgress);
}

// ── Delete file ───────────────────────────────────────────────
export async function deleteStorageFile(url: string): Promise<void> {
  try {
    const storageRef = ref(storage, url);
    await deleteObject(storageRef);
  } catch {
    // Ignore if file doesn't exist
  }
}
