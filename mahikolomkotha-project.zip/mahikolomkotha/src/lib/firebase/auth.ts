"use client";

import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  updateProfile,
  type User,
} from "firebase/auth";
import {
  doc,
  getDoc,
  setDoc,
  serverTimestamp,
  collection,
  query,
  where,
  getDocs,
} from "firebase/firestore";
import { auth, db } from "./config";
import type { AppUser, UserRole } from "@/types";

const ADMIN_EMAIL = process.env.NEXT_PUBLIC_ADMIN_EMAIL || "";

// ── Role resolution ───────────────────────────────────────────
async function resolveUserRole(email: string): Promise<UserRole> {
  if (email === ADMIN_EMAIL) return "admin";

  // Check if email is in invitedWriters
  const inviteRef = doc(db, "invitedWriters", email);
  const inviteSnap = await getDoc(inviteRef);
  if (inviteSnap.exists()) return "writer";

  return "reader";
}

// ── Create / update user doc ──────────────────────────────────
async function ensureUserDoc(user: User): Promise<AppUser> {
  const userRef = doc(db, "users", user.uid);
  const snap    = await getDoc(userRef);

  if (snap.exists()) {
    // Update last active
    await setDoc(userRef, { updatedAt: new Date().toISOString() }, { merge: true });
    return snap.data() as AppUser;
  }

  const role = await resolveUserRole(user.email!);
  const newUser: AppUser = {
    uid:         user.uid,
    email:       user.email!,
    displayName: user.displayName || user.email!.split("@")[0],
    photoURL:    user.photoURL || undefined,
    role,
    status:      "active",
    createdAt:   new Date().toISOString(),
    updatedAt:   new Date().toISOString(),
  };

  await setDoc(userRef, newUser);

  // If writer invite — mark as accepted
  if (role === "writer") {
    await setDoc(
      doc(db, "invitedWriters", user.email!),
      { status: "accepted" },
      { merge: true }
    );
  }

  return newUser;
}

// ── Public auth functions ─────────────────────────────────────
export async function signInWithGoogle(): Promise<AppUser> {
  const provider = new GoogleAuthProvider();
  const { user } = await signInWithPopup(auth, provider);
  return ensureUserDoc(user);
}

export async function signInWithEmail(
  email: string,
  password: string
): Promise<AppUser> {
  const { user } = await signInWithEmailAndPassword(auth, email, password);
  return ensureUserDoc(user);
}

export async function registerWithEmail(
  email: string,
  password: string,
  displayName: string
): Promise<AppUser> {
  const { user } = await createUserWithEmailAndPassword(auth, email, password);
  await updateProfile(user, { displayName });
  return ensureUserDoc(user);
}

export async function signOut(): Promise<void> {
  await firebaseSignOut(auth);
}

export async function getUserDoc(uid: string): Promise<AppUser | null> {
  const snap = await getDoc(doc(db, "users", uid));
  return snap.exists() ? (snap.data() as AppUser) : null;
}

// ── Admin: invite a writer ─────────────────────────────────────
export async function inviteWriter(
  adminUid: string,
  email: string
): Promise<void> {
  await setDoc(doc(db, "invitedWriters", email.toLowerCase()), {
    email:       email.toLowerCase(),
    invitedBy:   adminUid,
    invitedAt:   new Date().toISOString(),
    status:      "pending",
  });
}

export async function getInvitedWriters() {
  const snap = await getDocs(collection(db, "invitedWriters"));
  return snap.docs.map((d) => d.data());
}

export async function removeWriterInvite(email: string): Promise<void> {
  const { deleteDoc } = await import("firebase/firestore");
  await deleteDoc(doc(db, "invitedWriters", email));
  // Also downgrade the user if they exist
  const q = query(collection(db, "users"), where("email", "==", email));
  const snap = await getDocs(q);
  snap.docs.forEach(async (d) => {
    await setDoc(d.ref, { role: "reader" }, { merge: true });
  });
}

// ── Auth state listener ───────────────────────────────────────
export function onAuthChange(
  callback: (user: User | null) => void
): () => void {
  return onAuthStateChanged(auth, callback);
}
