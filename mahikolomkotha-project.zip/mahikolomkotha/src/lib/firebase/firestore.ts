import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  addDoc,
  increment,
} from "firebase/firestore";
import { db } from "./config";
import type { Idea, Publication, Comment } from "@/types";

// ── Ideas ─────────────────────────────────────────────────────
export async function createIdea(
  authorId: string,
  content: string,
  tags: string[] = []
): Promise<string> {
  const ref = doc(collection(db, "ideas"));
  const now = new Date().toISOString();
  await setDoc(ref, {
    id: ref.id,
    content,
    authorId,
    tags,
    status: "active",
    createdAt: now,
    updatedAt: now,
  } as Idea);
  return ref.id;
}

export async function getWriterIdeas(authorId: string): Promise<Idea[]> {
  const q = query(
    collection(db, "ideas"),
    where("authorId", "==", authorId),
    orderBy("createdAt", "desc")
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => d.data() as Idea);
}

export async function updateIdeaStatus(
  id: string,
  status: Idea["status"]
): Promise<void> {
  await updateDoc(doc(db, "ideas", id), {
    status,
    updatedAt: new Date().toISOString(),
  });
}

export async function deleteIdea(id: string): Promise<void> {
  await deleteDoc(doc(db, "ideas", id));
}

// ── Publications (Newspaper Archive) ─────────────────────────
export async function createPublication(
  data: Omit<Publication, "id" | "createdAt" | "updatedAt">
): Promise<string> {
  const ref = doc(collection(db, "publications"));
  const now = new Date().toISOString();
  await setDoc(ref, {
    ...data,
    id: ref.id,
    createdAt: now,
    updatedAt: now,
  } as Publication);
  return ref.id;
}

export async function getPublications(authorId?: string): Promise<Publication[]> {
  let q;
  if (authorId) {
    q = query(
      collection(db, "publications"),
      where("authorId", "==", authorId),
      orderBy("publicationDate", "desc")
    );
  } else {
    q = query(
      collection(db, "publications"),
      orderBy("publicationDate", "desc")
    );
  }
  const snap = await getDocs(q);
  return snap.docs.map((d) => d.data() as Publication);
}

export async function updatePublication(
  id: string,
  data: Partial<Publication>
): Promise<void> {
  await updateDoc(doc(db, "publications", id), {
    ...data,
    updatedAt: new Date().toISOString(),
  });
}

export async function deletePublication(id: string): Promise<void> {
  await deleteDoc(doc(db, "publications", id));
}

// ── Comments ──────────────────────────────────────────────────
export async function createComment(
  comment: Omit<Comment, "id" | "createdAt" | "updatedAt" | "repliesCount" | "likes">
): Promise<string> {
  const ref = doc(collection(db, "comments"));
  const now = new Date().toISOString();
  await setDoc(ref, {
    ...comment,
    id: ref.id,
    repliesCount: 0,
    likes: 0,
    createdAt: now,
    updatedAt: now,
  } as Comment);

  // Increment article comment count
  await updateDoc(doc(db, "articles", comment.articleId), {
    "stats.commentsCount": increment(1),
  });

  return ref.id;
}

export async function getApprovedComments(articleId: string): Promise<Comment[]> {
  const q = query(
    collection(db, "comments"),
    where("articleId", "==", articleId),
    where("status", "==", "approved"),
    where("parentId", "==", null),
    orderBy("isPinned", "desc"),
    orderBy("createdAt", "desc")
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => d.data() as Comment);
}

export async function getPendingComments(): Promise<Comment[]> {
  const q = query(
    collection(db, "comments"),
    where("status", "==", "pending"),
    orderBy("createdAt", "desc")
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => d.data() as Comment);
}

export async function approveComment(id: string): Promise<void> {
  await updateDoc(doc(db, "comments", id), {
    status: "approved",
    updatedAt: new Date().toISOString(),
  });
}

export async function deleteComment(id: string, articleId: string): Promise<void> {
  await deleteDoc(doc(db, "comments", id));
  await updateDoc(doc(db, "articles", articleId), {
    "stats.commentsCount": increment(-1),
  });
}

export async function pinComment(id: string, pinned: boolean): Promise<void> {
  await updateDoc(doc(db, "comments", id), {
    isPinned: pinned,
    updatedAt: new Date().toISOString(),
  });
}
