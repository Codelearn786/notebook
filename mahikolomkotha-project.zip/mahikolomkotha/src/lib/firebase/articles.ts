import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  type QueryDocumentSnapshot,
  increment,
  serverTimestamp,
  Timestamp,
  addDoc,
} from "firebase/firestore";
import { db } from "./config";
import type { Article, Draft, ContentType, ContentStatus } from "@/types";

// ── Helpers ──────────────────────────────────────────────────
function estimateReadTime(html: string): number {
  const words = html.replace(/<[^>]*>/g, "").split(/\s+/).length;
  return Math.max(1, Math.ceil(words / 200));
}

function generateExcerpt(html: string, length = 200): string {
  return html.replace(/<[^>]*>/g, "").slice(0, length) + "…";
}

// ── Articles ─────────────────────────────────────────────────
export async function createArticle(
  data: Omit<Article, "id" | "createdAt" | "updatedAt" | "stats">
): Promise<string> {
  const ref = doc(collection(db, "articles"));
  const now = new Date().toISOString();
  const article: Article = {
    ...data,
    id: ref.id,
    stats: {
      views: 0,
      likes: 0,
      commentsCount: 0,
      readTime: estimateReadTime(data.contentHTML),
    },
    createdAt: now,
    updatedAt: now,
  };
  await setDoc(ref, article);
  return ref.id;
}

export async function updateArticle(
  id: string,
  data: Partial<Article>
): Promise<void> {
  const ref = doc(db, "articles", id);
  await updateDoc(ref, {
    ...data,
    updatedAt: new Date().toISOString(),
    "stats.readTime": data.contentHTML
      ? estimateReadTime(data.contentHTML)
      : undefined,
  });
}

export async function getArticle(id: string): Promise<Article | null> {
  const snap = await getDoc(doc(db, "articles", id));
  return snap.exists() ? (snap.data() as Article) : null;
}

export async function getArticleBySlug(slug: string): Promise<Article | null> {
  const q = query(
    collection(db, "articles"),
    where("slug", "==", slug),
    where("status", "==", "published"),
    limit(1)
  );
  const snap = await getDocs(q);
  if (snap.empty) return null;
  return snap.docs[0].data() as Article;
}

export async function publishArticle(id: string): Promise<void> {
  await updateDoc(doc(db, "articles", id), {
    status:      "published" as ContentStatus,
    publishedAt: new Date().toISOString(),
    updatedAt:   new Date().toISOString(),
  });
}

export async function unpublishArticle(id: string): Promise<void> {
  await updateDoc(doc(db, "articles", id), {
    status:    "draft" as ContentStatus,
    updatedAt: new Date().toISOString(),
  });
}

export async function deleteArticle(id: string): Promise<void> {
  await deleteDoc(doc(db, "articles", id));
}

export async function getPublishedArticles(
  type?: ContentType,
  pageSize = 12,
  lastDoc?: QueryDocumentSnapshot
): Promise<{ articles: Article[]; lastDoc: QueryDocumentSnapshot | null }> {
  let q = query(
    collection(db, "articles"),
    where("status", "==", "published"),
    orderBy("publishedAt", "desc"),
    limit(pageSize)
  );

  if (type) {
    q = query(
      collection(db, "articles"),
      where("status", "==", "published"),
      where("type", "==", type),
      orderBy("publishedAt", "desc"),
      limit(pageSize)
    );
  }

  if (lastDoc) q = query(q, startAfter(lastDoc));

  const snap = await getDocs(q);
  return {
    articles: snap.docs.map((d) => d.data() as Article),
    lastDoc:  snap.docs[snap.docs.length - 1] ?? null,
  };
}

export async function getFeaturedArticles(): Promise<Article[]> {
  const q = query(
    collection(db, "articles"),
    where("status", "==", "published"),
    where("isFeatured", "==", true),
    orderBy("publishedAt", "desc"),
    limit(3)
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => d.data() as Article);
}

export async function getWriterArticles(authorId: string): Promise<Article[]> {
  const q = query(
    collection(db, "articles"),
    where("authorId", "==", authorId),
    orderBy("updatedAt", "desc")
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => d.data() as Article);
}

export async function incrementViews(id: string): Promise<void> {
  await updateDoc(doc(db, "articles", id), {
    "stats.views": increment(1),
  });
}

export async function toggleLike(
  articleId: string,
  userId: string
): Promise<boolean> {
  const likeRef = doc(db, "articleLikes", `${articleId}_${userId}`);
  const likeSnap = await getDoc(likeRef);

  if (likeSnap.exists()) {
    await deleteDoc(likeRef);
    await updateDoc(doc(db, "articles", articleId), {
      "stats.likes": increment(-1),
    });
    return false;
  } else {
    await setDoc(likeRef, {
      articleId,
      userId,
      createdAt: new Date().toISOString(),
    });
    await updateDoc(doc(db, "articles", articleId), {
      "stats.likes": increment(1),
    });
    return true;
  }
}

// ── Drafts ───────────────────────────────────────────────────
export async function saveDraft(
  draft: Omit<Draft, "id" | "createdAt">
): Promise<string> {
  const ref = doc(collection(db, "drafts"));
  const now = new Date().toISOString();
  await setDoc(ref, {
    ...draft,
    id: ref.id,
    createdAt: now,
    updatedAt: now,
    lastAutoSave: now,
  });
  return ref.id;
}

export async function autoSaveDraft(
  id: string,
  data: {
    title?: string;
    contentJSON?: Record<string, unknown>;
    wordCount?: number;
  }
): Promise<void> {
  const now = new Date().toISOString();
  await updateDoc(doc(db, "drafts", id), {
    ...data,
    lastAutoSave: now,
    updatedAt: now,
  });
}

export async function getDraft(id: string): Promise<Draft | null> {
  const snap = await getDoc(doc(db, "drafts", id));
  return snap.exists() ? (snap.data() as Draft) : null;
}

export async function getWriterDrafts(authorId: string): Promise<Draft[]> {
  const q = query(
    collection(db, "drafts"),
    where("authorId", "==", authorId),
    orderBy("lastAutoSave", "desc")
  );
  const snap = await getDocs(q);
  return snap.docs.map((d) => d.data() as Draft);
}

export async function deleteDraft(id: string): Promise<void> {
  await deleteDoc(doc(db, "drafts", id));
}
