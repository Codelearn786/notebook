// ── User types ──────────────────────────────────────────────
export type UserRole = "admin" | "writer" | "reader";

export interface AppUser {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: UserRole;
  bio?: string;
  status: "active" | "pending" | "blocked";
  createdAt: string;
  updatedAt: string;
}

export interface WriterInvite {
  email: string;
  invitedBy: string;
  invitedAt: string;
  status: "pending" | "accepted";
}

// ── Article types ────────────────────────────────────────────
export type ContentType = "article" | "poem" | "opinion" | "feature" | "heritage";
export type ContentStatus = "draft" | "published" | "archived";

export interface CoverImage {
  url: string;
  alt: string;
  caption?: string;
  storageRef?: string;
}

export interface Article {
  id: string;
  title: string;
  slug: string;
  contentJSON: Record<string, unknown>;
  contentHTML: string;
  excerpt: string;
  coverImage?: CoverImage;
  authorId: string;
  authorName: string;
  authorPhoto?: string;
  type: ContentType;
  tags: string[];
  status: ContentStatus;
  publishedAt?: string;
  createdAt: string;
  updatedAt: string;
  stats: {
    views: number;
    likes: number;
    commentsCount: number;
    readTime: number;
  };
  isFeatured: boolean;
  isPinned: boolean;
}

// ── Draft types ───────────────────────────────────────────────
export interface Draft {
  id: string;
  title: string;
  contentJSON: Record<string, unknown>;
  authorId: string;
  type: ContentType;
  lastAutoSave: string;
  wordCount: number;
  createdAt: string;
  updatedAt: string;
}

// ── Idea types ────────────────────────────────────────────────
export interface Idea {
  id: string;
  content: string;
  authorId: string;
  tags: string[];
  status: "active" | "used" | "archived";
  relatedArticleId?: string;
  createdAt: string;
  updatedAt: string;
}

// ── Publication (Newspaper archive) ─────────────────────────
export interface Publication {
  id: string;
  title: string;
  newspaperName: string;
  publicationDate: string;
  category: string;
  pdfUrl?: string;
  scanImage?: CoverImage;
  articleId?: string;
  tags: string[];
  authorId: string;
  createdAt: string;
  updatedAt: string;
}

// ── Comment types ─────────────────────────────────────────────
export interface Comment {
  id: string;
  articleId: string;
  authorId: string;
  authorName: string;
  authorPhoto?: string;
  content: string;
  parentId?: string;
  repliesCount: number;
  likes: number;
  status: "pending" | "approved" | "rejected";
  isPinned: boolean;
  createdAt: string;
  updatedAt: string;
}

// ── AI types ──────────────────────────────────────────────────
export type AIAction =
  | "improve"
  | "rewrite"
  | "expand"
  | "shorten"
  | "generate-title"
  | "generate-summary"
  | "facebook-caption"
  | "article-ideas";

export interface AIRequest {
  text: string;
  action: AIAction;
  context?: string;
}

export interface AIResponse {
  success: boolean;
  result: string;
  error?: string;
}

// ── Search types ──────────────────────────────────────────────
export interface SearchResult {
  id: string;
  title: string;
  excerpt: string;
  type: ContentType;
  slug: string;
  authorName: string;
  publishedAt: string;
  coverImage?: string;
}
