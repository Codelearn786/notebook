# মাহি কলম কথা — Mahikolomkotha

A mobile-first Bengali Writer Operating System built with Next.js 15, Firebase, TipTap, and Groq AI.

## ✨ Features

- **Writer Studio** — Full-screen Bengali editor with Word-style formatting
- **AI Assistant** — Groq-powered writing improvement, title generation, Facebook captions
- **Image Search** — Pixabay integration for free stock images
- **Auto-Save** — Every 3 seconds, with localStorage backup
- **Multi-Role** — Admin + invited Writers + Readers
- **Newspaper Archive** — Record publication history
- **Idea Vault** — Quick idea capture
- **PWA Ready** — Installable on mobile, offline support
- **Mobile-First** — Bottom navigation, full-screen editor

---

## 🚀 Deployment (Firebase App Hosting)

### Prerequisites
1. [Firebase CLI](https://firebase.google.com/docs/cli) installed: `npm install -g firebase-tools`
2. GitHub account with this code pushed to a repo
3. Firebase project: `mahikolomkotha`

---

### Step 1 — Set your Admin email

Open `apphosting.yaml` and replace `YOUR_ADMIN_EMAIL_HERE` with your Google/email account:

```yaml
- variable: NEXT_PUBLIC_ADMIN_EMAIL
  value: your-real-email@gmail.com
```

---

### Step 2 — Add Groq API Key to Firebase Secret Manager

The Groq key must be stored as a secret (not in code):

```bash
firebase login
firebase use mahikolomkotha
echo "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" | \
  firebase apphosting:secrets:set GROQ_API_KEY
```

---

### Step 3 — Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit — Mahikolomkotha"
git remote add origin https://github.com/YOUR_USERNAME/mahikolomkotha.git
git push -u origin main
```

---

### Step 4 — Enable Firebase App Hosting

1. Go to **Firebase Console** → your project `mahikolomkotha`
2. Click **App Hosting** in the left sidebar
3. Click **Get started**
4. Connect your **GitHub repository**
5. Set branch: `main`
6. Set root directory: `/` (root)
7. Click **Finish & Deploy**

Firebase automatically:
- Detects Next.js 15
- Reads `apphosting.yaml`
- Builds and deploys to Cloud Run
- Gives you a URL like `https://mahikolomkotha-xxxx.web.app`

---

### Step 5 — Deploy Firestore Rules & Indexes

```bash
firebase deploy --only firestore:rules,firestore:indexes,storage
```

---

### Step 6 — Enable Firebase Auth Providers

In **Firebase Console → Authentication → Sign-in method**:
- Enable **Google**
- Enable **Email/Password**

---

### Step 7 — Enable Firebase Storage

In **Firebase Console → Storage**:
- Click **Get started**
- Choose a region (e.g., `asia-south1` for India/Bangladesh)

---

## 🔑 Role System

| Role | How assigned | Can do |
|---|---|---|
| **Admin** | Matches `NEXT_PUBLIC_ADMIN_EMAIL` | Everything |
| **Writer** | Admin invites by email in Settings | Write, publish, use AI |
| **Reader** | Everyone else | Read, comment |

---

## 🏗️ Tech Stack

| Layer | Technology |
|---|---|
| Framework | Next.js 15.5 (App Router) |
| Language | TypeScript |
| Styling | Tailwind CSS v3 |
| Editor | TipTap v2 |
| Database | Firebase Firestore |
| Storage | Firebase Storage |
| Auth | Firebase Authentication |
| Hosting | Firebase App Hosting |
| AI | Groq (Llama 3.3 70B) |
| Images | Pixabay API |

---

## 📱 Running Locally

```bash
# 1. Copy environment file
cp .env.local.example .env.local
# Edit .env.local with your values (already filled with project keys)

# 2. Install dependencies
npm install

# 3. Start dev server
npm run dev
# → Open http://localhost:3000
```

---

## 🗂️ Project Structure

```
src/
├── app/
│   ├── (auth)/login/        # Login page
│   ├── (writer)/            # Writer-only pages (auth-guarded)
│   │   ├── studio/          # New article editor
│   │   ├── studio/[id]/     # Edit draft
│   │   ├── drafts/          # Draft list
│   │   ├── ideas/           # Idea vault
│   │   ├── archive/         # Newspaper archive
│   │   └── settings/        # Admin: invite writers
│   ├── articles/[slug]/     # Article reader
│   ├── poems/[slug]/        # Poem reader
│   ├── search/              # Search
│   └── api/ai/              # Groq proxy (server-side)
├── components/
│   ├── editor/              # TipTap editor + toolbar
│   ├── ai/                  # AI assistant panel
│   ├── media/               # Pixabay search
│   ├── article/             # Article card, share buttons
│   ├── writer/              # Publish modal
│   ├── layout/              # Navbar, mobile nav
│   └── ui/                  # Shadcn-style components
├── lib/firebase/            # All Firebase operations
├── hooks/                   # useAuth, useAutoSave
└── types/                   # TypeScript types
```

---

## 🔥 First Time Setup (After Deploy)

1. Open your app URL
2. Click **Sign In** → Sign in with your admin email
3. You're automatically the **Admin**
4. Go to **Settings** → Invite a writer by email
5. That writer signs up → gets Writer role automatically
6. Click **Write** → Start your first article!

---

## 📖 Bengali Typography

The app uses these Google Fonts (loaded via CSS):
- **Baloo Da 2** — Headings and titles
- **Noto Sans Bengali** — Body text
- **Hind Siliguri** — UI elements
- **Inter** — English UI text

Text alignment defaults to **justify** for a newspaper-style reading experience.

---

*মনের খাতা থেকে পাঠকের হৃদয়ে*  
*From the notebook of the mind to the heart of the reader*
